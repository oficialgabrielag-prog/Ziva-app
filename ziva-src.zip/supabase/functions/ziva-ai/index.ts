import { serve } from "https://deno.land/std/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const GEMINI_URL =
  "https://app-cuwiuhind9fl-api-VaOwP8E7dJqa.gateway.appmedo.com/v1beta/models/gemini-2.5-flash:streamGenerateContent?alt=sse";

// Statuses que justificam nova tentativa (gateway sobrecarregado / erro transitório)
const RETRIABLE = new Set([429, 500, 502, 503, 504]);

serve(async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  if (req.method !== "POST") return new Response("Method Not Allowed", { status: 405 });

  // ── Verificar autenticação do utilizador ──────────────────────────────────
  const authHeader = req.headers.get("Authorization") ?? "";
  if (authHeader) {
    try {
      const supabase = createClient(
        Deno.env.get("SUPABASE_URL")!,
        Deno.env.get("SUPABASE_ANON_KEY")!,
        { global: { headers: { Authorization: authHeader } } },
      );
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        return new Response(JSON.stringify({ error: "Não autorizado" }), {
          status: 401, headers: { ...CORS, "Content-Type": "application/json" },
        });
      }
    } catch { /* tolera falha de auth para chave anon */ }
  }

  // ── Ler corpo da requisição ───────────────────────────────────────────────
  let contents: unknown[];
  let systemInstruction: string | undefined;
  try {
    const body = await req.json();
    contents = body.contents;
    systemInstruction = body.systemInstruction;
    if (!Array.isArray(contents) || contents.length === 0) {
      throw new Error("contents vazio ou inválido");
    }
  } catch (e) {
    return new Response(JSON.stringify({ error: `Corpo inválido: ${(e as Error).message}` }), {
      status: 400, headers: { ...CORS, "Content-Type": "application/json" },
    });
  }

  // ── Chave de plataforma (nunca exposta ao cliente) ────────────────────────
  const apiKey = Deno.env.get("INTEGRATIONS_API_KEY");
  if (!apiKey) {
    return new Response(JSON.stringify({ error: "Configuração do servidor em falta" }), {
      status: 500, headers: { ...CORS, "Content-Type": "application/json" },
    });
  }

  // ── Construir payload para Gemini 2.5 Flash ───────────────────────────────
  const payload: Record<string, unknown> = { contents };
  if (systemInstruction) {
    payload.systemInstruction = {
      role: "user",
      parts: [{ text: systemInstruction }],
    };
  }
  payload.generationConfig = {
    temperature: 0.8,
    topP: 0.95,
    topK: 64,
    maxOutputTokens: 8192,
  };

  // ── Retry com backoff exponencial em 429/500/502/503/504 ─────────────────
  // 6 tentativas: ~150ms → 300ms → 600ms → 1200ms → 2000ms = ~4.3 s total máx
  const MAX_ATTEMPTS = 6;
  const RETRY_DELAYS_MS = [150, 300, 600, 1200, 2000];

  let upstream!: Response;
  let lastStatus = 0;

  for (let attempt = 0; attempt < MAX_ATTEMPTS; attempt++) {
    try {
      upstream = await fetch(GEMINI_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Gateway-Authorization": `Bearer ${apiKey}`,
        },
        body: JSON.stringify(payload),
      });
      lastStatus = upstream.status;
    } catch (_fetchErr) {
      // Erro de rede (DNS, timeout) — trata como 503 e retenta
      lastStatus = 503;
      if (attempt < MAX_ATTEMPTS - 1) {
        await new Promise((r) => setTimeout(r, RETRY_DELAYS_MS[attempt] ?? 2000));
        continue;
      }
      // Esgotadas as tentativas
      return new Response(
        JSON.stringify({ error: "busy" }),
        { status: 503, headers: { ...CORS, "Content-Type": "application/json" } },
      );
    }

    // Sucesso ou erro não-retriável (400, 401, 403…) → sair do loop
    if (!RETRIABLE.has(upstream.status)) break;

    // Consumir body antes de aguardar para não deixar ligação em aberto
    await upstream.text().catch(() => "");

    if (attempt < MAX_ATTEMPTS - 1) {
      const delay = RETRY_DELAYS_MS[attempt] ?? 2000;
      await new Promise((r) => setTimeout(r, delay));
    }
  }

  // Após todas as tentativas, se ainda erro retriável → devolver 503 ao cliente
  if (RETRIABLE.has(lastStatus)) {
    return new Response(
      JSON.stringify({ error: "busy" }),
      { status: 503, headers: { ...CORS, "Content-Type": "application/json" } },
    );
  }

  if (!upstream!.ok || !upstream!.body) {
    const errText = await upstream!.text().catch(() => `status ${upstream!.status}`);
    console.error("[aura-ai] upstream error", upstream!.status, errText.slice(0, 200));
    return new Response(JSON.stringify({ error: "busy" }), {
      status: 503, headers: { ...CORS, "Content-Type": "application/json" },
    });
  }

  // ── Passar o stream SSE directamente para o cliente ──────────────────────
  return new Response(upstream!.body, {
    headers: {
      ...CORS,
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      "X-Content-Type-Options": "nosniff",
    },
  });
});
