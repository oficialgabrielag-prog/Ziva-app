import { serve } from "https://deno.land/std/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  if (req.method !== "POST") return new Response("Method Not Allowed", { status: 405 });

  let input: string, voice: string, responseFormat: string;
  try {
    const body = await req.json();
    input = body.input;
    voice = body.voice ?? "heart";
    responseFormat = body.response_format ?? "mp3";
    if (!input) throw new Error("input obrigatório");
  } catch {
    return new Response(JSON.stringify({ error: "Corpo inválido" }), {
      status: 400, headers: { ...CORS, "Content-Type": "application/json" },
    });
  }

  const apiKey = Deno.env.get("INTEGRATIONS_API_KEY");
  if (!apiKey) return new Response(JSON.stringify({ error: "Configuração do servidor" }), {
    status: 500, headers: { ...CORS, "Content-Type": "application/json" },
  });

  const upstream = await fetch(
    "https://app-cuwiuhind9fl-api-GYX1lzGw01Xa.gateway.appmedo.com/v1/audio/speech",
    {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-Gateway-Authorization": `Bearer ${apiKey}` },
      body: JSON.stringify({ input, voice, response_format: responseFormat }),
    }
  );

  if (upstream.status === 429 || upstream.status === 402) {
    return new Response(await upstream.text(), { status: upstream.status, headers: { ...CORS, "Content-Type": "application/json" } });
  }
  if (!upstream.ok) {
    return new Response(JSON.stringify({ error: `Erro upstream: ${upstream.status}` }), {
      status: 502, headers: { ...CORS, "Content-Type": "application/json" },
    });
  }

  // Upload binary audio to Supabase Storage
  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );

  const ext = responseFormat === "wav" ? "wav" : responseFormat === "ogg" ? "ogg" : "mp3";
  const filePath = `tts/${crypto.randomUUID()}.${ext}`;

  const { error: uploadError } = await supabase.storage
    .from("ziva_images")
    .upload(filePath, upstream.body!, {
      contentType: `audio/${ext}`,
      cacheControl: "3600",
    } as RequestInit & { cacheControl: string });

  if (uploadError) {
    return new Response(JSON.stringify({ error: `Upload falhou: ${uploadError.message}` }), {
      status: 500, headers: { ...CORS, "Content-Type": "application/json" },
    });
  }

  const { data: urlData } = supabase.storage.from("ziva_images").getPublicUrl(filePath);
  return new Response(JSON.stringify({ audioUrl: urlData.publicUrl }), {
    status: 200, headers: { ...CORS, "Content-Type": "application/json" },
  });
});
