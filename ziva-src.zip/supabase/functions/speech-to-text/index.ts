import { serve } from "https://deno.land/std/http/server.ts";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  if (req.method !== "POST") return new Response("Method Not Allowed", { status: 405 });

  let fileUrl: string, language: string | undefined, responseFormat: string;
  try {
    const body = await req.json();
    fileUrl = body.fileUrl;
    language = body.language ?? "portuguese";
    responseFormat = body.responseFormat ?? "json";
    if (!fileUrl) throw new Error("fileUrl obrigatório");
  } catch {
    return new Response(JSON.stringify({ error: "Corpo inválido" }), {
      status: 400, headers: { ...CORS, "Content-Type": "application/json" },
    });
  }

  const apiKey = Deno.env.get("INTEGRATIONS_API_KEY");
  if (!apiKey) return new Response(JSON.stringify({ error: "Configuração do servidor" }), {
    status: 500, headers: { ...CORS, "Content-Type": "application/json" },
  });

  const params: Record<string, string> = {
    file: fileUrl,
    response_format: responseFormat,
  };
  if (language) params.language = language;

  const upstream = await fetch(
    "https://app-cuwiuhind9fl-api-DY8MNQoqOnMa.gateway.appmedo.com/v1/audio/transcriptions",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        "X-Gateway-Authorization": `Bearer ${apiKey}`,
      },
      body: new URLSearchParams(params).toString(),
    }
  );

  if (upstream.status === 429 || upstream.status === 402) {
    return new Response(await upstream.text(), { status: upstream.status, headers: { ...CORS, "Content-Type": "application/json" } });
  }
  if (!upstream.ok) {
    return new Response(JSON.stringify({ error: `Erro upstream: ${upstream.status}` }), {
      status: 502, headers: { ...CORS, "Content-Type": "application/json" },
    });
  }

  if (responseFormat === "text") {
    const text = await upstream.text();
    return new Response(JSON.stringify({ text }), { status: 200, headers: { ...CORS, "Content-Type": "application/json" } });
  }
  const data = await upstream.json();
  return new Response(JSON.stringify(data), { status: 200, headers: { ...CORS, "Content-Type": "application/json" } });
});
