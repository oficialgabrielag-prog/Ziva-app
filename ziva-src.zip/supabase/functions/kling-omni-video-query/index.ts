import { serve } from "https://deno.land/std/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const QUERY_BASE = "https://app-cuwiuhind9fl-api-pLVzAEz1ZQOL.gateway.appmedo.com/v1/videos/omni-video";
const BUCKET = "generated-media";

/** Transfere vídeo do CDN Kling para o Supabase Storage em background.
 *  Executado via waitUntil — nunca bloqueia a resposta ao cliente. */
async function transferAndSave(
  supabaseUrl: string,
  serviceKey: string,
  videoUrl: string,
  taskId: string,
  userId?: string,
  prompt?: string,
  duration?: string,
): Promise<void> {
  try {
    const supabase = createClient(supabaseUrl, serviceKey);

    // Descarregar o vídeo do CDN Kling
    const res = await fetch(videoUrl, { signal: AbortSignal.timeout(90_000) });
    if (!res.ok) return;

    const contentType = res.headers.get("content-type") ?? "video/mp4";
    const ext = contentType.includes("quicktime") ? "mov"
              : contentType.startsWith("video/") ? contentType.split("/")[1].split(";")[0]
              : "mp4";
    const filePath = `videos/${crypto.randomUUID()}.${ext}`;

    const { error: uploadErr } = await supabase.storage
      .from(BUCKET)
      .upload(filePath, res.body!, { contentType, cacheControl: "31536000", upsert: false });

    if (uploadErr) return;

    const { data } = supabase.storage.from(BUCKET).getPublicUrl(filePath);
    const storageUrl = data.publicUrl;

    // Gravar no histórico do utilizador
    if (userId) {
      await supabase.from("user_generated_videos").upsert({
        user_id: userId,
        task_id: taskId,
        prompt: prompt ?? '',
        video_url: videoUrl,
        storage_url: storageUrl,
        duration: duration ?? '5',
        status: 'completed',
      }, { onConflict: 'task_id' });
    }
  } catch {
    // Silencia erros — transferência em background não deve afectar o utilizador
  }
}

serve(async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  if (req.method !== "POST") return new Response("Method Not Allowed", { status: 405 });

  let taskId: string;
  let userId: string | undefined;
  let prompt: string | undefined;

  try {
    const body = await req.json();
    taskId = body.task_id;
    userId = body.user_id;
    prompt = body.prompt;
    if (!taskId) throw new Error("task_id obrigatório");
  } catch {
    return new Response(JSON.stringify({ error: "Corpo inválido" }), {
      status: 400, headers: { ...CORS, "Content-Type": "application/json" },
    });
  }

  const apiKey = Deno.env.get("INTEGRATIONS_API_KEY");
  if (!apiKey) return new Response(JSON.stringify({ error: "Configuração do servidor em falta" }), {
    status: 500, headers: { ...CORS, "Content-Type": "application/json" },
  });

  const upstream = await fetch(`${QUERY_BASE}/${encodeURIComponent(taskId)}`, {
    method: "GET",
    headers: { "Content-Type": "application/json", "X-Gateway-Authorization": `Bearer ${apiKey}` },
  }).catch(() => null);

  if (!upstream) {
    return new Response(JSON.stringify({ error: "Erro de ligação. Tenta novamente." }), {
      status: 502, headers: { ...CORS, "Content-Type": "application/json" },
    });
  }

  if (!upstream.ok) {
    return new Response(JSON.stringify({ error: `Erro do servidor de IA (${upstream.status})` }), {
      status: 502, headers: { ...CORS, "Content-Type": "application/json" },
    });
  }

  const result = await upstream.json();

  // Se o vídeo estiver pronto, iniciar a transferência em BACKGROUND via waitUntil
  // A resposta com a URL do CDN Kling é devolvida IMEDIATAMENTE ao cliente
  if (result?.data?.task_status === "succeed" && result?.data?.task_result?.videos?.length > 0) {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const mainVideo = result.data.task_result.videos[0];

    if (supabaseUrl && serviceKey) {
      // waitUntil: executa após a resposta ser enviada — nunca bloqueia o cliente
      (globalThis as any).EdgeRuntime?.waitUntil(
        transferAndSave(supabaseUrl, serviceKey, mainVideo.url, taskId, userId, prompt, mainVideo.duration)
      );
    }
  }

  // Devolve o resultado original (com URL CDN Kling) imediatamente
  return new Response(JSON.stringify(result), {
    status: 200, headers: { ...CORS, "Content-Type": "application/json" },
  });
});

serve(async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  if (req.method !== "POST") return new Response("Method Not Allowed", { status: 405 });

  let taskId: string;
  let userId: string | undefined;
  let prompt: string | undefined;

  try {
    const body = await req.json();
    taskId = body.task_id;
    userId = body.user_id;     // opcional: para gravar na BD do utilizador
    prompt = body.prompt;      // opcional: texto do prompt para histórico
    if (!taskId) throw new Error("task_id obrigatório");
  } catch {
    return new Response(JSON.stringify({ error: "Corpo inválido" }), {
      status: 400, headers: { ...CORS, "Content-Type": "application/json" },
    });
  }

  const apiKey = Deno.env.get("INTEGRATIONS_API_KEY");
  if (!apiKey) return new Response(JSON.stringify({ error: "Configuração do servidor em falta" }), {
    status: 500, headers: { ...CORS, "Content-Type": "application/json" },
  });

  const upstream = await fetch(`${QUERY_BASE}/${encodeURIComponent(taskId)}`, {
    method: "GET",
    headers: { "Content-Type": "application/json", "X-Gateway-Authorization": `Bearer ${apiKey}` },
  }).catch(() => null);

  if (!upstream) {
    return new Response(JSON.stringify({ error: "Erro de ligação. Tenta novamente." }), {
      status: 502, headers: { ...CORS, "Content-Type": "application/json" },
    });
  }

  if (!upstream.ok) {
    return new Response(JSON.stringify({ error: `Erro do servidor de IA (${upstream.status})` }), {
      status: 502, headers: { ...CORS, "Content-Type": "application/json" },
    });
  }

  const result = await upstream.json();

  // Se o vídeo estiver pronto, iniciar a transferência em BACKGROUND via waitUntil
  // A resposta com a URL do CDN Kling é devolvida IMEDIATAMENTE ao cliente
  if (result?.data?.task_status === "succeed" && result?.data?.task_result?.videos?.length > 0) {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const mainVideo = result.data.task_result.videos[0];

    if (supabaseUrl && serviceKey) {
      // waitUntil: executa após a resposta ser enviada — nunca bloqueia o cliente
      (globalThis as any).EdgeRuntime?.waitUntil(
        transferAndSave(supabaseUrl, serviceKey, mainVideo.url, taskId, userId, prompt, mainVideo.duration)
      );
    }
  }

  // Devolve o resultado original (com URL CDN Kling) imediatamente
  return new Response(JSON.stringify(result), {
    status: 200, headers: { ...CORS, "Content-Type": "application/json" },
  });
});
