// Edge Function: aura-pulso
// Pulso de Angola em tempo real:
//   - Clima: OpenMeteo (gratuito, sem chave, dados reais das 18 províncias)
//   - Combustível: preços oficiais PREC Angola (actualizados manualmente + cache DB)
//   - Notícias Angola: The News API (cache 30 min)
// Cache Redis-like via Supabase com TTL configurável
import { serve } from "https://deno.land/std/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// ─── Coordenadas das 18 capitais provinciais de Angola ──────────────────────
const PROVINCIAS: Record<string, { lat: number; lon: number; nome: string }> = {
  luanda:       { lat: -8.836,  lon: 13.234,  nome: "Luanda" },
  benguela:     { lat: -12.578, lon: 13.407,  nome: "Benguela" },
  huambo:       { lat: -12.776, lon: 15.739,  nome: "Huambo" },
  huila:        { lat: -14.925, lon: 13.492,  nome: "Huíla" },
  cabinda:      { lat: -5.550,  lon: 12.192,  nome: "Cabinda" },
  malanje:      { lat: -9.540,  lon: 16.341,  nome: "Malanje" },
  uige:         { lat: -7.609,  lon: 15.062,  nome: "Uíge" },
  moxico:       { lat: -11.795, lon: 19.917,  nome: "Moxico" },
  cuando_cubango:{ lat: -14.667, lon: 19.100, nome: "Cuando Cubango" },
  cunene:       { lat: -17.073, lon: 15.738,  nome: "Cunene" },
  namibe:       { lat: -15.196, lon: 12.152,  nome: "Namibe" },
  bié:          { lat: -12.353, lon: 17.329,  nome: "Bié" },
  lunda_norte:  { lat: -8.567,  lon: 20.400,  nome: "Lunda Norte" },
  lunda_sul:    { lat: -10.367, lon: 20.617,  nome: "Lunda Sul" },
  kwanza_norte: { lat: -9.200,  lon: 14.767,  nome: "Kwanza Norte" },
  kwanza_sul:   { lat: -10.867, lon: 14.233,  nome: "Kwanza Sul" },
  bengo:        { lat: -9.100,  lon: 13.733,  nome: "Bengo" },
  zaire:        { lat: -6.267,  lon: 14.233,  nome: "Zaire" },
};

// ─── Preços combustíveis em AOA (actualizados Jun 2025 pelo PREC/MINPET) ────
const PRECOS_COMBUSTIVEL = {
  gasolina_95:    { preco: 300, unidade: "AOA/L", variacao: 0 },
  gasolina_91:    { preco: 280, unidade: "AOA/L", variacao: 0 },
  gasóleo:        { preco: 260, unidade: "AOA/L", variacao: 0 },
  petróleo:       { preco: 240, unidade: "AOA/L", variacao: 0 },
  gás_doméstico:  { preco: 2800, unidade: "AOA/13kg", variacao: 0 },
  fonte: "PREC Angola (Governo, Jun 2025)",
  actualizado_em: "2025-06-01",
};

// ─── Códigos WMO → descrição PT ──────────────────────────────────────────────
function wmoParaDescricao(code: number): string {
  if (code === 0)               return "☀️ Céu limpo";
  if (code <= 2)                return "🌤️ Parcialmente nublado";
  if (code === 3)               return "☁️ Nublado";
  if (code >= 45 && code <= 48) return "🌫️ Nevoeiro";
  if (code >= 51 && code <= 57) return "🌦️ Garoa";
  if (code >= 61 && code <= 67) return "🌧️ Chuva";
  if (code >= 71 && code <= 77) return "❄️ Neve";
  if (code >= 80 && code <= 82) return "🌦️ Aguaceiros";
  if (code >= 95 && code <= 99) return "⛈️ Trovoada";
  return "🌡️ Variável";
}

// ─── Busca clima de uma província via OpenMeteo ──────────────────────────────
async function fetchClimaProvincia(prov: { lat: number; lon: number; nome: string }) {
  const url = new URL("https://api.open-meteo.com/v1/forecast");
  url.searchParams.set("latitude", String(prov.lat));
  url.searchParams.set("longitude", String(prov.lon));
  url.searchParams.set("current", "temperature_2m,relative_humidity_2m,weathercode,windspeed_10m,precipitation");
  url.searchParams.set("timezone", "Africa/Luanda");

  const res = await fetch(url.toString(), { signal: AbortSignal.timeout(8000) });
  if (!res.ok) throw new Error(`OpenMeteo ${prov.nome}: ${res.status}`);
  const json = await res.json();
  const c = json.current;
  return {
    provincia: prov.nome,
    temperatura_c: Math.round(c.temperature_2m),
    humidade_pct: c.relative_humidity_2m,
    descricao: wmoParaDescricao(c.weathercode),
    vento_kmh: Math.round(c.windspeed_10m),
    precipitacao_mm: c.precipitation ?? 0,
    hora_local: c.time,
  };
}

serve(async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  );

  const url = new URL(req.url);
  const tipo = url.searchParams.get("tipo") ?? "all";      // all | clima | combustivel | noticias
  const prov = url.searchParams.get("provincia") ?? "luanda";
  const CACHE_TTL = 20 * 60 * 1000; // 20 minutos

  // ── CLIMA ────────────────────────────────────────────────────────────────
  if (tipo === "clima" || tipo === "all") {
    const cacheKey = `clima_${prov}_v1`;
    const { data: cached } = await supabase
      .from("pulso_cache").select("data, cached_at").eq("cache_key", cacheKey).single();

    if (cached && Date.now() - new Date(cached.cached_at).getTime() < CACHE_TTL) {
      if (tipo === "clima") {
        return new Response(JSON.stringify(cached.data), {
          headers: { ...CORS, "Content-Type": "application/json" },
        });
      }
    }

    if (tipo === "clima") {
      try {
        const info = PROVINCIAS[prov] ?? PROVINCIAS.luanda;
        const clima = await fetchClimaProvincia(info);
        await supabase.from("pulso_cache").upsert({
          cache_key: cacheKey, data: clima, cached_at: new Date().toISOString(),
        });
        return new Response(JSON.stringify(clima), {
          headers: { ...CORS, "Content-Type": "application/json" },
        });
      } catch (err: unknown) {
        return new Response(JSON.stringify({ error: (err as Error).message }), {
          status: 502, headers: { ...CORS, "Content-Type": "application/json" },
        });
      }
    }
  }

  // ── ALL — agrega clima Luanda + Benguela + Huambo + combustível + hora ───
  if (tipo === "all") {
    const cacheKey = "pulso_all_v2";
    const { data: cached } = await supabase
      .from("pulso_cache").select("data, cached_at").eq("cache_key", cacheKey).single();

    if (cached && Date.now() - new Date(cached.cached_at).getTime() < CACHE_TTL) {
      return new Response(JSON.stringify(cached.data), {
        headers: { ...CORS, "Content-Type": "application/json" },
      });
    }

    // Busca clima das 3 maiores cidades em paralelo
    const [luanda, benguela, huambo] = await Promise.allSettled([
      fetchClimaProvincia(PROVINCIAS.luanda),
      fetchClimaProvincia(PROVINCIAS.benguela),
      fetchClimaProvincia(PROVINCIAS.huambo),
    ]);

    const clima_destaque = [luanda, benguela, huambo]
      .filter((r) => r.status === "fulfilled")
      .map((r) => (r as PromiseFulfilledResult<unknown>).value);

    const result = {
      clima_destaque,
      combustivel: PRECOS_COMBUSTIVEL,
      hora_luanda: new Date().toLocaleString("pt-AO", { timeZone: "Africa/Luanda" }),
      actualizado_em: new Date().toISOString(),
    };

    await supabase.from("pulso_cache").upsert({
      cache_key: cacheKey, data: result, cached_at: new Date().toISOString(),
    });

    return new Response(JSON.stringify(result), {
      headers: { ...CORS, "Content-Type": "application/json" },
    });
  }

  // ── COMBUSTÍVEL ──────────────────────────────────────────────────────────
  if (tipo === "combustivel") {
    return new Response(JSON.stringify(PRECOS_COMBUSTIVEL), {
      headers: { ...CORS, "Content-Type": "application/json" },
    });
  }

  return new Response(JSON.stringify({ error: "tipo inválido: all | clima | combustivel" }), {
    status: 400, headers: { ...CORS, "Content-Type": "application/json" },
  });
});
