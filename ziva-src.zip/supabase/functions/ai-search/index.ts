import { serve } from "https://deno.land/std/http/server.ts";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-gemini-key",
};

serve(async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  if (req.method !== "POST") return new Response("Method Not Allowed", { status: 405 });

  let contents: unknown[];
  try {
    const body = await req.json();
    contents = body.contents;
    if (!Array.isArray(contents) || contents.length === 0) throw new Error("contents vazio");
  } catch {
    return new Response(JSON.stringify({ error: "Corpo inválido" }), {
      status: 400, headers: { ...CORS, "Content-Type": "application/json" },
    });
  }

  const userKey = req.headers.get("x-gemini-key")?.trim();
  const geminiKey = userKey || Deno.env.get("GEMINI_API_KEY");
  const platformKey = Deno.env.get("INTEGRATIONS_API_KEY");

  if (!geminiKey && !platformKey) {
    return new Response(JSON.stringify({ error: "Nenhuma chave de API configurada." }), {
      status: 500, headers: { ...CORS, "Content-Type": "application/json" },
    });
  }

  // Usar generateContent (não streaming) — compatível com todos os browsers incluindo Safari iOS
  let upstreamUrl: string;
  let headers: Record<string, string>;

  // Tenta com chave do utilizador primeiro; se 429/falha, usa gateway da plataforma
  const attempts: Array<{ url: string; hdrs: Record<string, string> }> = [];

  if (geminiKey) {
    attempts.push({
      url: `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${geminiKey}`,
      hdrs: { "Content-Type": "application/json" },
    });
  }
  if (platformKey) {
    attempts.push({
      url: "https://app-cuwiuhind9fl-api-zYm4ze3j7XvL.gateway.appmedo.com/v1beta/models/gemini-1.5-flash:generateContent",
      hdrs: { "Content-Type": "application/json", "X-Gateway-Authorization": `Bearer ${platformKey}` },
    });
  }

  let lastErr = "";
  for (const attempt of attempts) {
    const upstream = await fetch(attempt.url, {
      method: "POST",
      headers: attempt.hdrs,
      body: JSON.stringify({ contents }),
    });

    if (upstream.ok) {
      const json = await upstream.json();
      return new Response(JSON.stringify(json), {
        headers: { ...CORS, "Content-Type": "application/json" },
      });
    }

    // Qualquer erro de upstream: regista e tenta o próximo (gateway)
    lastErr = await upstream.text().catch(() => `status ${upstream.status}`);
    continue;
  }

  // Todas as tentativas falharam
  return new Response(JSON.stringify({ error: `Serviço de IA indisponível. ${lastErr}` }), {
    status: 502, headers: { ...CORS, "Content-Type": "application/json" },
  });
});
