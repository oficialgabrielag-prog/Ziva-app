import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: req.headers.get("Authorization") ?? "" } } }
    );
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      return new Response(JSON.stringify({ error: "Não autorizado" }), {
        status: 401, headers: { ...CORS, "Content-Type": "application/json" },
      });
    }

    const url  = new URL(req.url);
    const type  = url.searchParams.get("type") ?? "users";
    const limit = Math.min(parseInt(url.searchParams.get("limit") ?? "10"), 30);

    const admin = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    // ── Utilizadores sugeridos ────────────────────────────────────────────
    if (type === "users") {
      const { data: followingData } = await admin
        .from("follows").select("following_id").eq("follower_id", user.id);
      const followingIds = (followingData ?? []).map((f: any) => f.following_id);
      followingIds.push(user.id);

      const { data: suggested } = await admin
        .from("profiles")
        .select("id, username, full_name, avatar_url, followers_count, bio, is_verified")
        .not("id", "in", `(${followingIds.join(",")})`)
        .order("followers_count", { ascending: false })
        .limit(limit);

      return new Response(JSON.stringify({ type: "users", data: suggested ?? [] }), {
        headers: { ...CORS, "Content-Type": "application/json" },
      });
    }

    // ── Posts em destaque (utilizadores não seguidos) ─────────────────────
    if (type === "posts") {
      const { data: followingData } = await admin
        .from("follows").select("following_id").eq("follower_id", user.id);
      const followingIds = (followingData ?? []).map((f: any) => f.following_id);
      followingIds.push(user.id);

      const since = new Date(Date.now() - 48 * 3600 * 1000).toISOString();
      const { data: posts } = await admin
        .from("posts")
        .select("id, caption, image_url, image_urls, likes_count, comments_count, created_at, user_id, profiles(id, username, avatar_url, is_verified)")
        .not("user_id", "in", `(${followingIds.join(",")})`)
        .gte("created_at", since)
        .eq("status", "published")
        .eq("is_deleted", false)
        .order("likes_count", { ascending: false })
        .limit(limit);

      return new Response(JSON.stringify({ type: "posts", data: posts ?? [] }), {
        headers: { ...CORS, "Content-Type": "application/json" },
      });
    }

    // ── Hashtags em tendência ─────────────────────────────────────────────
    if (type === "hashtags") {
      const { data: tags } = await admin.rpc("get_trending_hashtags", { lim: limit });
      return new Response(JSON.stringify({ type: "hashtags", data: tags ?? [] }), {
        headers: { ...CORS, "Content-Type": "application/json" },
      });
    }

    // ── Posts em Tendência (últimas 72h, todos os utilizadores) ───────────
    if (type === "trending") {
      const { data: trending } = await admin.rpc("get_trending_posts", { lim: limit });
      return new Response(JSON.stringify({ type: "trending", data: trending ?? [] }), {
        headers: { ...CORS, "Content-Type": "application/json" },
      });
    }

    // ── Criadores em Crescimento ──────────────────────────────────────────
    if (type === "creators") {
      const { data: creators } = await admin.rpc("get_rising_creators", {
        viewer: user.id, lim: limit,
      });
      return new Response(JSON.stringify({ type: "creators", data: creators ?? [] }), {
        headers: { ...CORS, "Content-Type": "application/json" },
      });
    }

    // ── Descoberta completa (todos os painéis de uma só vez) ───────────────
    if (type === "discover") {
      const { data: followingData } = await admin
        .from("follows").select("following_id").eq("follower_id", user.id);
      const followingIds = (followingData ?? []).map((f: any) => f.following_id);
      followingIds.push(user.id);

      const [
        trendingRes, creatorsRes, hashtagsRes, commRes, reelsRes
      ] = await Promise.all([
        // Posts em tendência
        admin.rpc("get_trending_posts", { lim: 10 }),
        // Criadores em crescimento
        admin.rpc("get_rising_creators", { viewer: user.id, lim: 8 }),
        // Hashtags em tendência
        admin.rpc("get_trending_hashtags", { lim: 12 }),
        // Comunidades recomendadas (maior crescimento de membros)
        admin.from("communities")
          .select("id, name, avatar_url, members_count, description")
          .order("members_count", { ascending: false })
          .limit(6),
        // Reels recomendados
        admin.from("posts")
          .select("id, caption, image_url, video_url, likes_count, views_count, profiles(id, username, avatar_url, is_verified)")
          .eq("post_type", "reel")
          .eq("status", "published")
          .eq("is_deleted", false)
          .not("video_url", "is", null)
          .gte("created_at", new Date(Date.now() - 72 * 3600 * 1000).toISOString())
          .order("likes_count", { ascending: false })
          .limit(10),
      ]);

      return new Response(JSON.stringify({
        type: "discover",
        trending:  trendingRes.data  ?? [],
        creators:  creatorsRes.data  ?? [],
        hashtags:  hashtagsRes.data  ?? [],
        communities: commRes.data    ?? [],
        reels:     (reelsRes.data ?? []).map((r: any) => ({
          ...r,
          profiles: Array.isArray(r.profiles) ? r.profiles[0] : r.profiles,
        })),
      }), { headers: { ...CORS, "Content-Type": "application/json" } });
    }

    return new Response(
      JSON.stringify({ error: `Tipo desconhecido: ${type}.` }),
      { status: 400, headers: { ...CORS, "Content-Type": "application/json" } }
    );

  } catch (err) {
    return new Response(
      JSON.stringify({ error: (err as Error).message }),
      { status: 500, headers: { ...CORS, "Content-Type": "application/json" } }
    );
  }
});
