import { serve } from "https://deno.land/std/http/server.ts";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const SUBMIT_URL = "https://app-cuwiuhind9fl-api-k93RvqRrRZba.gateway.appmedo.com/v1/videos/omni-video";

/** Tenta submeter a tarefa com retry automático em caso de 503/504 */
async function submitWithRetry(body: Record<string, unknown>, apiKey: string, maxRetries = 3): Promise<Response> {
  let lastResponse: Response | null = null;
  for (let attempt = 0; attempt < maxRetries; attempt++) {
    if (attempt > 0) await new Promise(r => setTimeout(r, 1500 * attempt)); // backoff: 1.5s, 3s
    lastResponse = await fetch(SUBMIT_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-Gateway-Authorization": `Bearer ${apiKey}` },
      body: JSON.stringify(body),
    });
    // Não repetir em erros de autenticação/quota — apenas em erros temporários do servidor
    if (lastResponse.status !== 503 && lastResponse.status !== 504) break;
  }
  return lastResponse!;
}

serve(async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  if (req.method !== "POST") return new Response("Method Not Allowed", { status: 405 });

  let body: Record<string, unknown>;
  try {
    body = await req.json();
    if (!body.multi_shot && !body.prompt) throw new Error("prompt obrigatório no modo single");
    if (body.multi_shot && !body.multi_prompt) throw new Error("multi_prompt obrigatório no modo multi");
  } catch (e) {
    return new Response(JSON.stringify({ error: (e as Error).message || "Corpo inválido" }), {
      status: 400, headers: { ...CORS, "Content-Type": "application/json" },
    });
  }

  const apiKey = Deno.env.get("INTEGRATIONS_API_KEY");
  if (!apiKey) return new Response(JSON.stringify({ error: "Configuração do servidor em falta" }), {
    status: 500, headers: { ...CORS, "Content-Type": "application/json" },
  });

  let upstream: Response;
  try {
    upstream = await submitWithRetry(body, apiKey);
  } catch (e) {
    return new Response(JSON.stringify({ error: "Erro de ligação ao servidor de IA. Tenta novamente." }), {
      status: 502, headers: { ...CORS, "Content-Type": "application/json" },
    });
  }

  // 429 = quota excedida temporariamente; 402 = saldo insuficiente na conta
  if (upstream.status === 429) {
    return new Response(
      JSON.stringify({ error: "O gerador de IA está muito ocupado. Aguarda alguns segundos e tenta novamente." }),
      { status: 429, headers: { ...CORS, "Content-Type": "application/json" } }
    );
  }
  if (upstream.status === 402) {
    return new Response(
      JSON.stringify({ error: "Serviço de geração de vídeo temporariamente indisponível. A equipa Ziva foi notificada. Tenta mais tarde." }),
      { status: 402, headers: { ...CORS, "Content-Type": "application/json" } }
    );
  }
  if (!upstream.ok) {
    const errText = await upstream.text().catch(() => '');
    return new Response(JSON.stringify({ error: `Erro interno do servidor de IA (${upstream.status}). Tenta novamente.` }), {
      status: 502, headers: { ...CORS, "Content-Type": "application/json" },
    });
  }

  const data = await upstream.json();
  return new Response(JSON.stringify(data), { status: 200, headers: { ...CORS, "Content-Type": "application/json" } });
});
