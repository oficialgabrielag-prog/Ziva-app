import { serve } from "https://deno.land/std/http/server.ts";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  if (req.method !== "POST") return new Response("Method Not Allowed", { status: 405 });

  let body: Record<string, unknown>;
  try {
    body = await req.json();
    if (!body.prompt) throw new Error("prompt obrigatório");
  } catch {
    return new Response(JSON.stringify({ error: "Corpo inválido" }), {
      status: 400, headers: { ...CORS, "Content-Type": "application/json" },
    });
  }

  if (body.result_type === "single" && "series_amount" in body) {
    return new Response(JSON.stringify({ error: "series_amount não deve ser enviado no modo single" }), {
      status: 400, headers: { ...CORS, "Content-Type": "application/json" },
    });
  }

  const apiKey = Deno.env.get("INTEGRATIONS_API_KEY");
  if (!apiKey) return new Response(JSON.stringify({ error: "Configuração do servidor" }), {
    status: 500, headers: { ...CORS, "Content-Type": "application/json" },
  });

  const upstream = await fetch(
    "https://app-cuwiuhind9fl-api-2Y00Vzbe0MBY.gateway.appmedo.com/v1/images/omni-image",
    {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-Gateway-Authorization": `Bearer ${apiKey}` },
      body: JSON.stringify(body),
    }
  );

  if (upstream.status === 429 || upstream.status === 402) {
    return new Response(await upstream.text(), { status: upstream.status, headers: { ...CORS, "Content-Type": "application/json" } });
  }
  if (!upstream.ok) {
    return new Response(JSON.stringify({ error: `Erro upstream: ${upstream.status}` }), {
      status: 502, headers: { ...CORS, "Content-Type": "application/json" },
    });
  }

  const data = await upstream.json();
  return new Response(JSON.stringify(data), { status: 200, headers: { ...CORS, "Content-Type": "application/json" } });
});
