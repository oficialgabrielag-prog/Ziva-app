import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });

  try {
    // Autenticar utilizador
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: req.headers.get("Authorization") ?? "" } } }
    );
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      return new Response(JSON.stringify({ error: "Não autorizado" }), {
        status: 401, headers: { ...CORS, "Content-Type": "application/json" },
      });
    }

    const body = await req.json();
    const { content, content_type = "text" } = body as {
      content: string;
      content_type?: "text" | "caption" | "comment" | "bio";
    };

    if (!content?.trim()) {
      return new Response(JSON.stringify({ safe: true, score: 0, reason: null }), {
        headers: { ...CORS, "Content-Type": "application/json" },
      });
    }

    const apiKey = Deno.env.get("INTEGRATIONS_API_KEY");
    if (!apiKey) throw new Error("Configuração do servidor em falta");

    // Usar LLM para moderação de conteúdo
    const systemPrompt = `És um moderador de conteúdo para uma rede social chamada Ziva (português de Angola).
Analisa o conteúdo fornecido e determina se é seguro para publicação.
Devolve SEMPRE um JSON com:
- safe: boolean (true = seguro, false = viola as regras)
- score: number 0-100 (0 = totalmente seguro, 100 = extremamente prejudicial)
- categories: array de strings com categorias violadas (ex: ["spam", "ódio", "adulto", "violência"])
- reason: string | null (motivo se não for seguro, null se for seguro)
Regras: sem discurso de ódio, sem conteúdo adulto explícito, sem spam, sem violência extrema, sem informações pessoais de terceiros.
Responde SOMENTE com JSON válido, sem markdown.`;

    const llmRes = await fetch(
      "https://app-cuwiuhind9fl-api-k93RvqRrRZba.gateway.appmedo.com/v1/chat/completions",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Gateway-Authorization": `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: "gpt-4o-mini",
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: `Tipo: ${content_type}\nConteúdo: ${content.slice(0, 2000)}` },
          ],
          temperature: 0.1,
          max_tokens: 256,
          response_format: { type: "json_object" },
        }),
      }
    );

    if (!llmRes.ok) throw new Error(`LLM error: ${llmRes.status}`);
    const llmData = await llmRes.json();
    const resultText = llmData.choices?.[0]?.message?.content ?? "{}";
    const result = JSON.parse(resultText);

    // Registar resultado de moderação para posts/comments se não for seguro
    if (!result.safe && result.score >= 70) {
      const adminClient = createClient(
        Deno.env.get("SUPABASE_URL")!,
        Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
      );
      await adminClient.from("moderation_logs").insert({
        user_id: user.id,
        content_type,
        content_snippet: content.slice(0, 200),
        safety_score: result.score,
        categories: result.categories ?? [],
        reason: result.reason,
      }).maybeSingle();
    }

    return new Response(JSON.stringify({
      safe: result.safe ?? true,
      score: result.score ?? 0,
      categories: result.categories ?? [],
      reason: result.reason ?? null,
    }), { headers: { ...CORS, "Content-Type": "application/json" } });

  } catch (err) {
    return new Response(
      JSON.stringify({ error: (err as Error).message }),
      { status: 500, headers: { ...CORS, "Content-Type": "application/json" } }
    );
  }
});
