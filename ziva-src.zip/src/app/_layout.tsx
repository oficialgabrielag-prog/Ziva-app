import { Stack } from 'expo-router';
import { PortalHost } from '@rn-primitives/portal';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { ActivityIndicator, View, Text, Pressable, useColorScheme } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { ThemeProvider } from '@react-navigation/native';
import React from 'react';

import { SessionProvider, useSession } from '@/ctx';
import { NAV_THEME, Z } from '@/lib/theme';
import { ZivaThemeProvider } from '@/lib/theme-context';
import "../global.css";

// ─── ErrorBoundary global — captura erros de render silenciosos ───────────────
interface EBState { hasError: boolean; error: string | null }
class AppErrorBoundary extends React.Component<{ children: React.ReactNode }, EBState> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, error: null };
  }
  static getDerivedStateFromError(err: unknown): EBState {
    const msg = err instanceof Error ? err.message : String(err);
    console.error('[ZivaError]', msg);
    return { hasError: true, error: msg };
  }
  componentDidCatch(err: unknown, info: React.ErrorInfo) {
    console.error('[ZivaCrash]', err, info.componentStack);
  }
  render() {
    if (this.state.hasError) {
      return (
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: '#09090B', padding: 24 }}>
          <Text style={{ color: '#7B3FF2', fontSize: 48, fontWeight: '900', marginBottom: 8 }}>Z</Text>
          <Text style={{ color: '#F9FAFB', fontSize: 18, fontWeight: '700', marginBottom: 8 }}>Ocorreu um erro</Text>
          <Text style={{ color: '#9CA3AF', fontSize: 13, textAlign: 'center', marginBottom: 24 }}>{this.state.error}</Text>
          <Pressable
            onPress={() => this.setState({ hasError: false, error: null })}
            style={{ backgroundColor: '#7B3FF2', paddingHorizontal: 28, paddingVertical: 12, borderRadius: 16 }}
          >
            <Text style={{ color: '#fff', fontWeight: '700' }}>Tentar novamente</Text>
          </Pressable>
        </View>
      );
    }
    return this.props.children;
  }
}

function RootLayoutNav() {
  // boot diagnostic
  React.useEffect(() => { console.log('[ZivaBoot] RootLayoutNav mounted'); }, []);
  const { session, isLoading } = useSession();
  const colorScheme = (useColorScheme() ?? 'dark') as 'light' | 'dark';
  const isDark = colorScheme === 'dark';
  const bgColor = isDark ? Z.dark.bg : Z.light.bg;

  if (isLoading) {
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: bgColor }}>
        <ActivityIndicator size="large" color="#7B3FF2" />
      </View>
    );
  }

  return (
    <ThemeProvider value={NAV_THEME[colorScheme]}>
      <StatusBar style={isDark ? 'light' : 'dark'} backgroundColor={bgColor} />
      <Stack screenOptions={{ headerShown: false }}>
        <Stack.Protected guard={!session}>
          <Stack.Screen name="index" />
          <Stack.Screen name="(auth)" />
        </Stack.Protected>
        <Stack.Protected guard={!!session}>
          <Stack.Screen name="(app)" />
        </Stack.Protected>
      </Stack>
    </ThemeProvider>
  );
}

export default function RootLayout() {
  return (
    <AppErrorBoundary>
      <GestureHandlerRootView style={{ flex: 1 }}>
        <ZivaThemeProvider>
          <SessionProvider>
            <RootLayoutNav />
            <PortalHost />
          </SessionProvider>
        </ZivaThemeProvider>
      </GestureHandlerRootView>
    </AppErrorBoundary>
  );
}
