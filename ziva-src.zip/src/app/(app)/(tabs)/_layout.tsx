import { Tabs, useRouter } from 'expo-router';
import { Home, Users, Bell, User } from 'lucide-react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { View, Text, Pressable } from 'react-native';
import { ZivaIcon } from '@/components/ZivaIcon';
import { useUnread } from '@/lib/unread-context';
import { MEDO_BADGE_CLEARANCE } from '@/lib/constants';
import { useZivaTheme } from '@/lib/theme-context';

/* ─── Ícone genérico ─────────────────────────────────────────────────── */
interface TabIconProps {
  color: string;
  size: number;
  focused: boolean;
  Icon: React.ComponentType<{ size: number; color: string; strokeWidth?: number }>;
  label: string;
  badge?: number;
}

function TabIcon({ color, size, focused, Icon, badge }: TabIconProps) {
  const { colors } = useZivaTheme();
  return (
    <View style={{ alignItems: 'center', justifyContent: 'center', gap: 2 }}>
      <View>
        <Icon size={size} color={color} strokeWidth={focused ? 2.4 : 1.6} />
        {badge != null && badge > 0 && (
          <View style={{
            position: 'absolute', top: -4, right: -6,
            minWidth: 16, height: 16, borderRadius: 8,
            backgroundColor: '#EF4444',
            alignItems: 'center', justifyContent: 'center',
            paddingHorizontal: 3,
            borderWidth: 1.5, borderColor: colors.bg,
          }}>
            <Text style={{ color: '#fff', fontSize: 9, fontWeight: '800', includeFontPadding: false }}>
              {badge > 99 ? '99+' : badge}
            </Text>
          </View>
        )}
      </View>
      {focused && (
        <View style={{ width: 4, height: 4, borderRadius: 2, backgroundColor: '#7B3FF2' }} />
      )}
    </View>
  );
}

/* ─── Botão Ziva central — navega para /aura-chat ───────────────────── */
function ZivaCenterButton({ focused }: { focused: boolean }) {
  const router = useRouter();
  return (
    <Pressable
      onPress={() => router.push('/(app)/aura-chat' as any)}
      style={{ alignItems: 'center', justifyContent: 'center', marginBottom: 8 }}
    >
      {focused && (
        <View style={{
          position: 'absolute',
          width: 62, height: 62, borderRadius: 31,
          backgroundColor: 'rgba(123,63,242,0.25)',
        }} />
      )}
      <View style={{
        width: 52, height: 52, borderRadius: 26,
        backgroundColor: '#3B82F6',
        alignItems: 'center', justifyContent: 'center',
        shadowColor: '#7B3FF2',
        shadowOffset: { width: 0, height: 6 },
        shadowOpacity: 0.5,
        shadowRadius: 14,
        elevation: 10,
      }}>
        <View style={{
          position: 'absolute', width: 52, height: 52, borderRadius: 26,
          backgroundColor: '#7B3FF2', opacity: 0.65,
        }} />
        <Text style={{
          fontSize: 24, fontWeight: '900', color: '#fff',
          includeFontPadding: false, zIndex: 1,
        }}>Z</Text>
      </View>
    </Pressable>
  );
}

/* ─── Layout principal dos tabs ──────────────────────────────────────── */
export default function TabsLayout() {
  const { colors } = useZivaTheme();
  const insets = useSafeAreaInsets();
  const { notifCount, msgCount } = useUnread();

  return (
    <Tabs
      initialRouteName="home"
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: '#7B3FF2',
        tabBarInactiveTintColor: colors.muted,
        tabBarStyle: {
          height: 64 + insets.bottom + MEDO_BADGE_CLEARANCE,
          paddingBottom: insets.bottom + 4 + MEDO_BADGE_CLEARANCE,
          paddingTop: 6,
          backgroundColor: colors.card,
          borderTopColor: colors.border,
          borderTopWidth: 1,
          shadowColor: '#000',
          shadowOffset: { width: 0, height: -4 },
          shadowOpacity: 0.4,
          shadowRadius: 12,
          elevation: 20,
        },
        tabBarShowLabel: true,
        tabBarLabelStyle: { fontSize: 10, fontWeight: '600', marginTop: 1 },
      }}
    >
      {/* ── Início ── */}
      <Tabs.Screen
        name="home"
        options={{
          title: 'Início',
          tabBarIcon: ({ color, size, focused }) => (
            <TabIcon color={color} size={size} focused={focused} Icon={Home} label="Início" />
          ),
        }}
      />

      {/* ── Amigos ── */}
      <Tabs.Screen
        name="search"
        options={{
          title: 'Amigos',
          tabBarIcon: ({ color, size, focused }) => (
            <TabIcon color={color} size={size} focused={focused} Icon={Users} label="Amigos" badge={msgCount} />
          ),
        }}
      />

      {/* ── Aura — botão central: tabBarButton redireciona para /aura-chat ── */}
      <Tabs.Screen
        name="ziva-ia"
        options={{
          title: 'Aura',
          tabBarLabelStyle: { display: 'none' },
          tabBarButton: () => <ZivaCenterButton focused={false} />,
        }}
      />

      {/* ── Alertas ── */}
      <Tabs.Screen
        name="notifications"
        options={{
          title: 'Alertas',
          tabBarIcon: ({ color, size, focused }) => (
            <TabIcon color={color} size={size} focused={focused} Icon={Bell} label="Alertas" badge={notifCount} />
          ),
        }}
      />

      {/* ── Marketplace — oculto da barra (acessível via TopBar) ── */}
      <Tabs.Screen
        name="marketplace"
        options={{ href: null, title: 'Loja' }}
      />

      {/* ── Perfil ── */}
      <Tabs.Screen
        name="profile"
        options={{
          title: 'Perfil',
          tabBarIcon: ({ color, size, focused }) => (
            <TabIcon color={color} size={size} focused={focused} Icon={User} label="Perfil" />
          ),
        }}
      />

      {/* Tabs ocultas */}
      <Tabs.Screen name="create" options={{ href: null, title: 'Criar' }} />
      <Tabs.Screen
        name="reels"
        options={{ href: null, title: 'Reels', tabBarStyle: { display: 'none' } }}
      />
    </Tabs>
  );
}
