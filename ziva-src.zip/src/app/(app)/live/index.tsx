import { useState, useCallback } from 'react';
import {
  View, Text, FlatList, Pressable, TextInput,
  ActivityIndicator, Modal, KeyboardAvoidingView,
} from 'react-native';
import { useFocusEffect, useRouter } from 'expo-router';
import { Image } from 'expo-image';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Plus, Radio, Eye, X } from 'lucide-react-native';
import type { RelativePathString } from 'expo-router';

import { supabase } from '@/client/supabase';
import { useSession } from '@/ctx';

// ─── Types ───────────────────────────────────────────────────────────────────
interface Live {
  id: string;
  title: string;
  status: string;
  viewer_count: number;
  started_at: string | null;
  host: { username: string; avatar_url: string; full_name: string };
}

// ─── Ecrã de Lives ────────────────────────────────────────────────────────────
export default function LivesScreen() {
  const { session } = useSession();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const userId = session?.user?.id ?? '';

  const [lives, setLives] = useState<Live[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [creating, setCreating] = useState(false);

  useFocusEffect(
    useCallback(() => {
      (async () => {
        setLoading(true);
        const { data } = await supabase
          .from('lives')
          .select('*, host:profiles!lives_host_id_fkey(username, avatar_url, full_name)')
          .in('status', ['waiting', 'live'])
          .order('viewer_count', { ascending: false });
        setLives((data as Live[]) ?? []);
        setLoading(false);
      })();
    }, [])
  );

  const startLive = async () => {
    if (!newTitle.trim() || creating) return;
    setCreating(true);
    const { data } = await supabase
      .from('lives')
      .insert({ host_id: userId, title: newTitle.trim(), status: 'live', started_at: new Date().toISOString() })
      .select('id')
      .single();

    if (data?.id) {
      // Notificar seguidores
      const { data: followers } = await supabase
        .from('follows')
        .select('follower_id')
        .eq('following_id', userId);

      if (followers && followers.length > 0) {
        await supabase.from('notifications').insert(
          followers.map((f) => ({
            user_id: f.follower_id,
            type: 'live',
            actor_id: userId,
            live_id: data.id,
            message: `está ao vivo agora!`,
          }))
        );
      }

      setShowCreate(false);
      setNewTitle('');
      router.push(`/(app)/live/${data.id}` as RelativePathString);
    }
    setCreating(false);
  };

  const renderLive = ({ item }: { item: Live }) => (
    <Pressable
      onPress={() => router.push(`/(app)/live/${item.id}` as RelativePathString)}
      className="mb-4 mx-4 rounded-2xl overflow-hidden bg-card border border-border"
      style={{ borderCurve: 'continuous' }}
    >
      {/* Miniatura / avatar do host */}
      <View className="relative h-44 bg-muted items-center justify-center">
        {item.host.avatar_url ? (
          <Image
            source={{ uri: item.host.avatar_url }}
            style={{ width: '100%', height: '100%', position: 'absolute' }}
            contentFit="cover"
          />
        ) : (
          <View className="w-20 h-20 rounded-full bg-primary/20 items-center justify-center">
            <Radio size={32} color="#7c3aed" />
          </View>
        )}
        {/* Badge AO VIVO */}
        <View className="absolute top-3 left-3 bg-red-500 rounded-full px-2 py-0.5 flex-row items-center gap-1">
          <View className="w-2 h-2 rounded-full bg-white" />
          <Text className="text-white text-xs font-bold">AO VIVO</Text>
        </View>
        {/* Viewers */}
        <View className="absolute top-3 right-3 bg-black/60 rounded-full px-2 py-0.5 flex-row items-center gap-1">
          <Eye size={12} color="#fff" />
          <Text className="text-white text-xs font-semibold">{item.viewer_count}</Text>
        </View>
      </View>

      <View className="p-3 flex-row items-center gap-3">
        <Image
          source={item.host.avatar_url ? { uri: item.host.avatar_url } : undefined}
          style={{ width: 36, height: 36, borderRadius: 18, borderWidth: 2, borderColor: '#ff0050' }}
        />
        <View className="flex-1">
          <Text className="text-foreground font-bold text-sm" numberOfLines={1}>{item.title || 'Live sem título'}</Text>
          <Text className="text-muted-foreground text-xs">@{item.host.username}</Text>
        </View>
        <Pressable
          onPress={() => router.push(`/(app)/live/${item.id}` as RelativePathString)}
          className="bg-primary rounded-full px-3 py-1.5"
        >
          <Text className="text-primary-foreground text-xs font-bold">Entrar</Text>
        </Pressable>
      </View>
    </Pressable>
  );

  return (
    <View className="flex-1 bg-background">
      <StatusBar style="dark" />

      {/* Header */}
      <View
        className="flex-row items-center justify-between px-4 pb-3 border-b border-border"
        style={{ paddingTop: insets.top + 8 }}
      >
        <Text className="text-2xl font-bold text-foreground">Lives 🔴</Text>
        <Pressable
          onPress={() => setShowCreate(true)}
          className="flex-row items-center gap-2 bg-primary rounded-full px-4 py-2"
        >
          <Plus size={16} color="#fff" />
          <Text className="text-white font-bold text-sm">Iniciar</Text>
        </Pressable>
      </View>

      {loading ? (
        <View className="flex-1 items-center justify-center">
          <ActivityIndicator color="#7c3aed" size="large" />
        </View>
      ) : lives.length === 0 ? (
        <View className="flex-1 items-center justify-center gap-4 px-8">
          <Radio size={56} color="#7c3aed" strokeWidth={1.5} />
          <Text className="text-foreground text-xl font-bold text-center">Nenhuma live no momento</Text>
          <Text className="text-muted-foreground text-center text-sm">
            Sê o primeiro a iniciar uma transmissão ao vivo para os teus seguidores!
          </Text>
          <Pressable onPress={() => setShowCreate(true)} className="bg-primary rounded-full px-6 py-3 mt-2">
            <Text className="text-primary-foreground font-bold">Iniciar Live</Text>
          </Pressable>
        </View>
      ) : (
        <FlatList
          data={lives}
          keyExtractor={(l) => l.id}
          renderItem={renderLive}
          contentInsetAdjustmentBehavior="automatic"
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingVertical: 16 }}
        />
      )}

      {/* Modal criar live */}
      <Modal visible={showCreate} transparent animationType="slide">
        <View className="flex-1 justify-end bg-black/50">
          <KeyboardAvoidingView behavior={process.env.EXPO_OS === 'ios' ? 'padding' : 'height'}>
            <View className="bg-background rounded-t-3xl px-6 pt-6 pb-10 gap-4">
              <View className="flex-row items-center justify-between mb-2">
                <Text className="text-xl font-bold text-foreground">Iniciar Live</Text>
                <Pressable onPress={() => setShowCreate(false)}>
                  <X size={22} color="#9ca3af" />
                </Pressable>
              </View>

              <TextInput
                value={newTitle}
                onChangeText={setNewTitle}
                placeholder="Título da live (ex: Tarde de música 🎵)"
                placeholderTextColor="#9ca3af"
                className="bg-muted rounded-xl px-4 py-3 text-foreground text-base border border-border"
                maxLength={80}
              />

              <Pressable
                onPress={startLive}
                disabled={creating || !newTitle.trim()}
                className="bg-primary rounded-2xl py-4 items-center"
                style={{ opacity: creating || !newTitle.trim() ? 0.6 : 1 }}
              >
                {creating ? (
                  <ActivityIndicator color="#fff" />
                ) : (
                  <Text className="text-primary-foreground font-bold text-base">🔴 Ir ao Vivo</Text>
                )}
              </Pressable>
            </View>
          </KeyboardAvoidingView>
        </View>
      </Modal>
    </View>
  );
}
