import { useState, useEffect, useRef, useCallback } from 'react';
import {
  View, Text, FlatList, Pressable, TextInput,
  KeyboardAvoidingView, ActivityIndicator,
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { Image } from 'expo-image';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import {
  X, Send, Eye, CameraOff, MicOff, Mic,
  RotateCcw as FlipIcon, Radio,
} from 'lucide-react-native';
import { CameraView, useCameraPermissions, useMicrophonePermissions, CameraType } from 'expo-camera';

import { supabase } from '@/client/supabase';
import { useSession } from '@/ctx';

// ─── Types ───────────────────────────────────────────────────────────────────
interface Live {
  id: string;
  title: string;
  status: string;
  viewer_count: number;
  host_id: string;
  started_at: string | null;
  host: { username: string; avatar_url: string; full_name: string };
}

interface LiveMessage {
  id: string;
  message: string;
  created_at: string;
  sender: { username: string; avatar_url: string };
}

interface FloatingEmoji {
  id: string;
  emoji: string;
  x: number;
}

const REACTION_EMOJIS = ['❤️', '🔥', '😂', '👏', '💜', '😮', '👍'];

// ─── Componente Principal ─────────────────────────────────────────────────────
export default function LiveViewerScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { session } = useSession();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const listRef = useRef<FlatList>(null);

  const [live, setLive] = useState<Live | null>(null);
  const [messages, setMessages] = useState<LiveMessage[]>([]);
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const [floatingEmojis, setFloatingEmojis] = useState<FloatingEmoji[]>([]);
  const userId = session?.user?.id ?? '';

  // Câmera e microfone — apenas para o host
  const [cameraPermission, requestCameraPermission] = useCameraPermissions();
  const [micPermission, requestMicPermission]       = useMicrophonePermissions();
  const [facing, setFacing]       = useState<CameraType>('front');
  const [camEnabled, setCamEnabled] = useState(true);
  const [micEnabled, setMicEnabled] = useState(true);
  // Deteção de live encerrada
  const [liveEnded, setLiveEnded] = useState(false);

  // Carregar live e mensagens
  useEffect(() => {
    if (!id) return;

    const fetchLive = async () => {
      const { data } = await supabase
        .from('lives')
        .select('*, host:profiles!lives_host_id_fkey(username, avatar_url, full_name)')
        .eq('id', id)
        .single();
      if (data) setLive(data as Live);
    };

    const fetchMessages = async () => {
      const { data } = await supabase
        .from('live_messages')
        .select('*, sender:profiles!live_messages_user_id_fkey(username, avatar_url)')
        .eq('live_id', id)
        .order('created_at', { ascending: true })
        .limit(100);
      if (data) setMessages(data as LiveMessage[]);
    };

    fetchLive();
    fetchMessages();

    // Incrementar viewer count
    supabase.rpc('increment_live_viewers', { live_id_arg: id });

    // Solicitar permissões de câmera + microfone ao entrar (apenas host)
    (async () => {
      if (!cameraPermission?.granted) await requestCameraPermission();
      if (!micPermission?.granted)    await requestMicPermission();
    })();

    // Subscrever novas mensagens e actualizações da live em tempo real
    const channel = supabase
      .channel(`live:${id}`)
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'live_messages',
        filter: `live_id=eq.${id}`,
      }, async (payload) => {
        const { data } = await supabase
          .from('live_messages')
          .select('*, sender:profiles!live_messages_user_id_fkey(username, avatar_url)')
          .eq('id', payload.new.id)
          .single();
        if (data) {
          setMessages((prev) => [...prev, data as LiveMessage]);
          setTimeout(() => listRef.current?.scrollToEnd({ animated: true }), 100);
        }
      })
      .on('postgres_changes', {
        event: 'UPDATE',
        schema: 'public',
        table: 'lives',
        filter: `id=eq.${id}`,
      }, (payload) => {
        const updated = payload.new as Partial<Live>;
        setLive((prev) => prev ? { ...prev, ...updated } : prev);
        // Detetar encerramento da live
        if (updated.status === 'ended') setLiveEnded(true);
      })
      .subscribe();

    return () => {
      supabase.rpc('decrement_live_viewers', { live_id_arg: id });
      supabase.removeChannel(channel);
    };
  }, [id]);

  const sendMessage = useCallback(async () => {
    if (!text.trim() || sending || !id) return;
    setSending(true);
    const msg = text.trim();
    setText('');
    await supabase.from('live_messages').insert({ live_id: id, user_id: userId, message: msg });
    setSending(false);
  }, [text, sending, id, userId]);

  const sendReaction = useCallback(async (emoji: string) => {
    if (!id) return;
    // Animação local
    const newEmoji: FloatingEmoji = { id: Date.now().toString(), emoji, x: Math.random() * 200 + 50 };
    setFloatingEmojis((prev) => [...prev, newEmoji]);
    setTimeout(() => setFloatingEmojis((prev) => prev.filter((e) => e.id !== newEmoji.id)), 1500);
    // Guardar no DB
    await supabase.from('live_reactions').insert({ live_id: id, user_id: userId, reaction: emoji });
  }, [id, userId]);

  const isHost = live?.host_id === userId;

  const endLive = async () => {
    if (!isHost || !id) return;
    await supabase.from('lives').update({
      status: 'ended',
      ended_at: new Date().toISOString(),
    }).eq('id', id);
    router.back();
  };

  // Ecrã de live encerrada (espectadores)
  if (liveEnded && !isHost) {
    return (
      <View style={{ flex: 1, backgroundColor: '#000', alignItems: 'center', justifyContent: 'center', gap: 16, paddingHorizontal: 32 }}>
        <StatusBar style="light" />
        <Radio size={56} color="#7c3aed" strokeWidth={1.5} />
        <Text style={{ color: '#fff', fontSize: 20, fontWeight: '800', textAlign: 'center' }}>
          A live encerrou
        </Text>
        <Text style={{ color: '#9ca3af', fontSize: 14, textAlign: 'center' }}>
          @{live?.host?.username} terminou a transmissão.
        </Text>
        <Pressable
          onPress={() => router.back()}
          style={{ backgroundColor: '#7c3aed', borderRadius: 24, paddingHorizontal: 28, paddingVertical: 12, marginTop: 8 }}
        >
          <Text style={{ color: '#fff', fontWeight: '700', fontSize: 15 }}>Fechar</Text>
        </Pressable>
      </View>
    );
  }

  if (!live) {
    return (
      <View className="flex-1 bg-black items-center justify-center">
        <ActivityIndicator color="#7c3aed" size="large" />
      </View>
    );
  }

  return (
    <View className="flex-1 bg-black">
      <StatusBar style="light" />

      {/* Câmera do host (fullscreen) ou fundo para espectadores */}
      {isHost ? (
        process.env.EXPO_OS === 'web' ? (
          <View className="absolute inset-0 bg-gray-900 items-center justify-center gap-3">
            <CameraOff size={48} color="#6b7280" />
            <Text style={{ color: '#9ca3af', fontSize: 14 }}>Câmera disponível apenas na app móvel</Text>
          </View>
        ) : cameraPermission?.granted ? (
          camEnabled ? (
            <CameraView
              style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }}
              facing={facing}
              mute={!micEnabled}
            />
          ) : (
            <View style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: '#111', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
              <CameraOff size={48} color="#6b7280" />
              <Text style={{ color: '#9ca3af', fontSize: 13 }}>Câmera desligada</Text>
            </View>
          )
        ) : (
          <View className="absolute inset-0 bg-gray-900 items-center justify-center gap-4 px-8">
            <CameraOff size={48} color="#9ca3af" />
            <Text style={{ color: '#fff', fontSize: 16, fontWeight: '700', textAlign: 'center' }}>
              Câmera não autorizada
            </Text>
            <Text style={{ color: '#9ca3af', fontSize: 13, textAlign: 'center' }}>
              Para transmitir ao vivo, o Ziva precisa de acesso à câmera.
            </Text>
            <Pressable
              onPress={requestCameraPermission}
              style={{ backgroundColor: '#7c3aed', borderRadius: 12, paddingHorizontal: 24, paddingVertical: 12 }}
            >
              <Text style={{ color: '#fff', fontWeight: '700' }}>Permitir câmera</Text>
            </Pressable>
          </View>
        )
      ) : (
        /* Espectador: fundo preto com indicador de transmissão */
        <View style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: '#050505', alignItems: 'center', justifyContent: 'center', gap: 16 }}>
          {live.host.avatar_url ? (
            <Image
              source={{ uri: live.host.avatar_url }}
              style={{ width: 110, height: 110, borderRadius: 55, borderWidth: 3, borderColor: '#7c3aed' }}
              contentFit="cover"
            />
          ) : null}
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: 'rgba(239,68,68,0.2)', borderRadius: 20, paddingHorizontal: 14, paddingVertical: 7, borderWidth: 1, borderColor: 'rgba(239,68,68,0.4)' }}>
            <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: '#ef4444' }} />
            <Text style={{ color: '#fca5a5', fontSize: 13, fontWeight: '700' }}>TRANSMISSÃO AO VIVO</Text>
          </View>
          <Text style={{ color: '#9ca3af', fontSize: 12, textAlign: 'center', paddingHorizontal: 32 }}>
            O vídeo ao vivo requer a app nativa instalada no dispositivo.
          </Text>
        </View>
      )}

      {/* Controlos do host: câmera on/off + microfone on/off + virar câmera */}
      {isHost && cameraPermission?.granted && process.env.EXPO_OS !== 'web' && (
        <View
          style={{
            position: 'absolute', top: 0, right: 0, zIndex: 25,
            flexDirection: 'column', gap: 8,
            paddingRight: 12,
          }}
          // eslint-disable-next-line react-native/no-inline-styles
          pointerEvents="box-none"
        >
          {/* Virar câmera */}
          <Pressable
            onPress={() => setFacing((f) => (f === 'front' ? 'back' : 'front'))}
            style={{ backgroundColor: 'rgba(0,0,0,0.55)', borderRadius: 22, padding: 10, marginTop: insets.top + 8 }}
          >
            <FlipIcon size={20} color="#fff" />
          </Pressable>
          {/* Toggle câmera */}
          <Pressable
            onPress={() => setCamEnabled((v) => !v)}
            style={{ backgroundColor: camEnabled ? 'rgba(0,0,0,0.55)' : 'rgba(239,68,68,0.7)', borderRadius: 22, padding: 10 }}
          >
            <CameraOff size={20} color="#fff" />
          </Pressable>
          {/* Toggle microfone */}
          <Pressable
            onPress={() => setMicEnabled((v) => !v)}
            style={{ backgroundColor: micEnabled ? 'rgba(0,0,0,0.55)' : 'rgba(239,68,68,0.7)', borderRadius: 22, padding: 10 }}
          >
            {micEnabled ? <Mic size={20} color="#fff" /> : <MicOff size={20} color="#fff" />}
          </Pressable>
        </View>
      )}

      {/* Header */}
      <View
        className="absolute top-0 left-0 right-0 flex-row items-center px-4 gap-3 z-20"
        style={{ paddingTop: insets.top + 8 }}
      >
        <Image
          source={live.host.avatar_url ? { uri: live.host.avatar_url } : undefined}
          style={{ width: 40, height: 40, borderRadius: 20, borderWidth: 2, borderColor: '#ff0050' }}
        />
        <View className="flex-1">
          <Text className="text-white font-bold text-sm">@{live.host.username}</Text>
          <Text className="text-red-400 text-xs font-semibold">🔴 AO VIVO</Text>
        </View>
        <View className="flex-row items-center gap-1 bg-black/50 rounded-full px-3 py-1">
          <Eye size={14} color="#fff" />
          <Text className="text-white text-xs font-bold">{live.viewer_count}</Text>
        </View>
        {isHost ? (
          <Pressable onPress={endLive} className="bg-red-500 rounded-full px-3 py-1">
            <Text className="text-white text-xs font-bold">Encerrar</Text>
          </Pressable>
        ) : (
          <Pressable onPress={() => router.back()} className="bg-black/50 rounded-full p-2">
            <X size={18} color="#fff" />
          </Pressable>
        )}
      </View>

      {/* Título da live */}
      {live.title ? (
        <View className="absolute z-10 left-4 right-4" style={{ top: insets.top + 72 }}>
          <Text className="text-white text-lg font-bold">{live.title}</Text>
        </View>
      ) : null}

      {/* Emojis flutuantes */}
      {floatingEmojis.map((fe) => (
        <View
          key={fe.id}
          className="absolute z-30 pointer-events-none"
          style={{ bottom: 160, left: fe.x }}
        >
          <Text style={{ fontSize: 28 }}>{fe.emoji}</Text>
        </View>
      ))}

      {/* Chat */}
      <KeyboardAvoidingView
        behavior={process.env.EXPO_OS === 'ios' ? 'padding' : 'height'}
        className="absolute bottom-0 left-0 right-0 z-10"
        style={{ paddingBottom: insets.bottom + 8 }}
      >
        {/* Lista de mensagens */}
        <FlatList
          ref={listRef}
          data={messages}
          keyExtractor={(m) => m.id}
          style={{ maxHeight: 220, paddingHorizontal: 12 }}
          showsVerticalScrollIndicator={false}
          renderItem={({ item }) => (
            <View className="flex-row items-start gap-2 mb-1">
              <Image
                source={item.sender.avatar_url ? { uri: item.sender.avatar_url } : undefined}
                style={{ width: 22, height: 22, borderRadius: 11, marginTop: 2 }}
              />
              <View className="flex-1 bg-black/50 rounded-xl px-2 py-1">
                <Text className="text-purple-300 text-xs font-bold">@{item.sender.username}</Text>
                <Text className="text-white text-sm">{item.message}</Text>
              </View>
            </View>
          )}
          onContentSizeChange={() => listRef.current?.scrollToEnd({ animated: false })}
        />

        {/* Reações rápidas */}
        <View className="flex-row items-center gap-2 px-3 py-2">
          {REACTION_EMOJIS.slice(0, 5).map((emoji) => (
            <Pressable
              key={emoji}
              onPress={() => sendReaction(emoji)}
              className="bg-black/50 rounded-full px-2 py-1"
            >
              <Text style={{ fontSize: 18 }}>{emoji}</Text>
            </Pressable>
          ))}
        </View>

        {/* Input */}
        <View className="flex-row items-center gap-2 px-3">
          <TextInput
            value={text}
            onChangeText={setText}
            placeholder="Escreve um comentário…"
            placeholderTextColor="#9ca3af"
            style={{
              flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', borderRadius: 24,
              paddingHorizontal: 14, paddingVertical: 8, color: '#fff', fontSize: 14,
              borderWidth: 1, borderColor: 'rgba(124,58,237,0.4)',
            }}
            returnKeyType="send"
            onSubmitEditing={sendMessage}
          />
          <Pressable onPress={sendMessage} className="bg-purple-600 rounded-full p-2">
            <Send size={18} color="#fff" />
          </Pressable>
        </View>
      </KeyboardAvoidingView>
    </View>
  );
}
