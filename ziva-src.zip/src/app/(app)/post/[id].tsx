import { useState, useCallback, useRef, useEffect } from 'react';
import {
  View, Text, FlatList, Pressable, ActivityIndicator,
  KeyboardAvoidingView, Modal, ScrollView,
} from 'react-native';
import { useFocusEffect, useRouter, useLocalSearchParams } from 'expo-router';
import { Image } from 'expo-image';
import {
  ArrowLeft, Heart, Send, MessageCircle, Pin, Pencil, Trash,
  MoreHorizontal, Reply, X, Check, Mic, MicOff, Play, Pause, BadgeCheck,
} from 'lucide-react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';

import { supabase } from '@/client/supabase';
import { useZivaTheme } from '@/lib/theme-context';
import { useSession } from '@/ctx';
import { MentionInput, resolveMentions } from '@/components/MentionInput';
import { VerifiedBadge } from '@/components/VerifiedBadge';

// Áudio — importado estaticamente, verificado por plataforma em runtime
import * as ExpoAudioModule from 'expo-audio';

// ─── Reprodutor de áudio — wrapper para isolar o hook nativo ─────────────────
function NativeAudioPlayer({ url, playing, onToggle, onProgress, onEnd }: {
  url: string; playing: boolean;
  onToggle: () => void; onProgress: (pos: number, dur: number) => void; onEnd: () => void;
}) {
  const player = ExpoAudioModule.useAudioPlayer(url);
  useEffect(() => {
    const sub = player.addListener('playbackStatusUpdate', (status: any) => {
      if (status.duration) onProgress(status.currentTime ?? 0, status.duration);
      if (status.didJustFinish) onEnd();
    });
    return () => { sub?.remove(); };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [player]);
  useEffect(() => {
    if (playing) player.play(); else player.pause();
  }, [playing, player]);
  return null;
}

// ─── Reprodutor de áudio para comentários com audio_url ─────────────────────
function AudioCommentPlayer({ url }: { url: string }) {
  const [playing, setPlaying] = useState(false);
  const [duration, setDuration] = useState(0);
  const [position, setPosition] = useState(0);
  const webAudioRef = useRef<any>(null);
  const intervalRef = useRef<any>(null);

  const blobUrlRef = useRef<string | null>(null);

  const handleProgress = (pos: number, dur: number) => { setPosition(pos); setDuration(dur); };
  const handleEnd = () => { setPlaying(false); setPosition(0); clearInterval(intervalRef.current); };

  const togglePlay = async () => {
    if (process.env.EXPO_OS !== 'web') {
      setPlaying((p) => !p);
    } else {
      if (!webAudioRef.current) {
        // Busca como blob para evitar problemas de CORS com currentTime no Safari
        try {
          const resp = await fetch(url);
          const blob = await resp.blob();
          const blobUrl = URL.createObjectURL(blob);
          blobUrlRef.current = blobUrl;
          const audio = new Audio(blobUrl);
          audio.preload = 'auto';
          audio.onended = handleEnd;
          audio.ondurationchange = () => {
            if (audio.duration && isFinite(audio.duration)) setDuration(audio.duration);
          };
          webAudioRef.current = audio;
        } catch {
          return; // falha silenciosa — URL inacessível
        }
      }
      const audio = webAudioRef.current;
      if (playing) {
        audio.pause(); setPlaying(false); clearInterval(intervalRef.current);
      } else {
        try { await audio.play(); } catch { /* autoplay bloqueado */ }
        setPlaying(true);
        intervalRef.current = setInterval(() => setPosition(audio.currentTime), 200);
      }
    }
  };

  useEffect(() => () => {
    clearInterval(intervalRef.current);
    webAudioRef.current?.pause();
    if (blobUrlRef.current) URL.revokeObjectURL(blobUrlRef.current);
  }, []);

  const progress = duration > 0 && isFinite(duration) ? position / duration : 0;
  const formatTime = (s: number) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;
  const BARS = [4,8,14,10,18,12,20,9,16,11,19,7,15,13,17,10,14,8,12,6];

  return (
    <View className="flex-row items-center gap-2 bg-primary/10 rounded-2xl px-3 py-2 mt-1" style={{ maxWidth: 260 }}>
      {process.env.EXPO_OS !== 'web' && (
        <NativeAudioPlayer url={url} playing={playing} onToggle={togglePlay} onProgress={handleProgress} onEnd={handleEnd} />
      )}
      <Pressable onPress={togglePlay} className="w-9 h-9 rounded-full bg-primary items-center justify-center active:opacity-70">
        {playing ? <Pause size={16} color="#fff" fill="#fff" /> : <Play size={16} color="#fff" fill="#fff" />}
      </Pressable>
      <View className="flex-row items-center gap-px flex-1" style={{ height: 24 }}>
        {BARS.map((h, i) => (
          <View key={i} style={{ flex: 1, height: h, borderRadius: 2,
            backgroundColor: i / BARS.length <= progress ? '#7c3aed' : 'rgba(156,163,175,0.4)' }} />
        ))}
      </View>
      <Text className="text-xs text-muted-foreground" style={{ minWidth: 36 }}>
        {duration > 0 && isFinite(duration)
          ? `${formatTime(position)}/${formatTime(duration)}`
          : playing ? formatTime(position) : '0:00'}
      </Text>
    </View>
  );
}

interface Comment {
  id: string;
  content: string;
  audio_url?: string | null;
  created_at: string;
  user_id: string;
  parent_id: string | null;
  is_pinned: boolean;
  likes_count: number;
  liked?: boolean;
  profiles: { username: string; avatar_url: string; is_verified?: boolean };
  replies?: Comment[];
}

interface Post {
  id: string;
  caption: string;
  image_url: string;
  likes_count: number;
  comments_count: number;
  created_at: string;
  user_id: string;
  profiles: { id: string; username: string; avatar_url: string; full_name?: string; is_verified?: boolean };
  liked?: boolean;
}

function timeAgo(dateStr: string): string {
  const seconds = Math.floor((Date.now() - new Date(dateStr).getTime()) / 1000);
  if (seconds < 60) return `${seconds}s`;
  if (seconds < 3600) return `${Math.floor(seconds / 60)}min`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h`;
  return `${Math.floor(seconds / 86400)}d`;
}

// ─── CommentItem with threading, edit, delete, pin, like ────────────────────
function CommentItem({
  comment,
  postOwnerId,
  currentUserId,
  onReply,
  onDelete,
  onEdit,
  onPin,
  onLike,
  depth = 0,
}: {
  comment: Comment;
  postOwnerId: string;
  currentUserId: string;
  onReply: (c: Comment) => void;
  onDelete: (id: string) => void;
  onEdit: (c: Comment) => void;
  onPin: (id: string, pinned: boolean) => void;
  onLike: (id: string, liked: boolean) => void;
  depth?: number;
}) {
  const [menuOpen, setMenuOpen] = useState(false);
  const isOwn = comment.user_id === currentUserId;
  const isPostOwner = postOwnerId === currentUserId;

  return (
    <View style={{ marginLeft: depth * 36, marginBottom: 4 }}>
      {comment.is_pinned && (
        <View className="flex-row items-center gap-1 px-4 mb-1">
          <Pin size={11} color="#7c3aed" />
          <Text className="text-primary text-xs font-semibold">Fixado</Text>
        </View>
      )}
      <View className="flex-row items-start px-4 py-1.5 gap-2.5">
        <Image
          source={comment.profiles.avatar_url ? { uri: comment.profiles.avatar_url } : undefined}
          style={{ width: 32, height: 32, borderRadius: 16, marginTop: 2 }}
          contentFit="cover"
          placeholder={{ blurhash: 'LGF5]+Yk^6#M@-5c,1J5@[or[Q6.' }}
        />
        <View className="flex-1">
          <View className="bg-muted rounded-2xl px-3 py-2.5">
            <View className="flex-row items-center gap-1">
              <Text className="font-bold text-foreground text-xs">{comment.profiles.username}</Text>
              {comment.profiles.is_verified && <BadgeCheck size={13} color="#7c3aed" />}
            </View>
            {comment.content && comment.content !== '🎤' && (
              <Text className="text-foreground text-sm mt-0.5 leading-5">{comment.content}</Text>
            )}
            {comment.audio_url && (
              <AudioCommentPlayer url={comment.audio_url} />
            )}
            {!comment.audio_url && comment.content === '🎤' && (
              <Text className="text-foreground text-sm mt-0.5 leading-5">🎤</Text>
            )}
          </View>
          {/* Action row */}
          <View className="flex-row items-center gap-4 mt-1 px-1">
            <Text className="text-muted-foreground text-xs">{timeAgo(comment.created_at)}</Text>
            {/* Like comment */}
            <Pressable className="flex-row items-center gap-1 active:opacity-60"
              onPress={() => onLike(comment.id, !!comment.liked)}>
              <Heart size={13}
                color={comment.liked ? '#db2777' : '#9ca3af'}
                fill={comment.liked ? '#db2777' : 'transparent'}
                strokeWidth={2} />
              {comment.likes_count > 0 && (
                <Text className="text-xs text-muted-foreground">{comment.likes_count}</Text>
              )}
            </Pressable>
            {/* Reply */}
            {depth === 0 && (
              <Pressable className="flex-row items-center gap-1 active:opacity-60"
                onPress={() => onReply(comment)}>
                <Reply size={13} color="#9ca3af" />
                <Text className="text-xs text-muted-foreground">Responder</Text>
              </Pressable>
            )}
            {/* More menu */}
            {(isOwn || isPostOwner) && (
              <Pressable onPress={() => setMenuOpen(true)} className="active:opacity-60">
                <MoreHorizontal size={16} color="#9ca3af" />
              </Pressable>
            )}
          </View>
        </View>
      </View>

      {/* Replies */}
      {(comment.replies ?? []).map((reply) => (
        <CommentItem key={reply.id} comment={reply} postOwnerId={postOwnerId}
          currentUserId={currentUserId} onReply={onReply} onDelete={onDelete}
          onEdit={onEdit} onPin={onPin} onLike={onLike} depth={1} />
      ))}

      {/* Context menu */}
      <Modal visible={menuOpen} transparent animationType="fade" onRequestClose={() => setMenuOpen(false)}>
        <Pressable style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'center', alignItems: 'center' }}
          onPress={() => setMenuOpen(false)}>
          <View className="bg-card rounded-2xl overflow-hidden mx-8" style={{ width: 260 }}>
            {isOwn && (
              <Pressable className="flex-row items-center gap-3 px-5 py-4 border-b border-border active:bg-muted"
                onPress={() => { setMenuOpen(false); onEdit(comment); }}>
                <Pencil size={18} color="#374151" />
                <Text className="text-foreground font-medium">Editar comentário</Text>
              </Pressable>
            )}
            {isPostOwner && (
              <Pressable className="flex-row items-center gap-3 px-5 py-4 border-b border-border active:bg-muted"
                onPress={() => { setMenuOpen(false); onPin(comment.id, comment.is_pinned); }}>
                <Pin size={18} color="#7c3aed" />
                <Text className="text-foreground font-medium">
                  {comment.is_pinned ? 'Desafixar' : 'Fixar comentário'}
                </Text>
              </Pressable>
            )}
            {(isOwn || isPostOwner) && (
              <Pressable className="flex-row items-center gap-3 px-5 py-4 active:bg-muted"
                onPress={() => { setMenuOpen(false); onDelete(comment.id); }}>
                <Trash size={18} color="#ef4444" />
                <Text style={{ color: '#ef4444' }} className="font-medium">Eliminar</Text>
              </Pressable>
            )}
          </View>
        </Pressable>
      </Modal>
    </View>
  );
}

// Hook de gravação de áudio para comentários — sempre chamado (regra dos Hooks)
function useCommentAudio() {
  // Hooks NUNCA podem ser chamados condicionalmente — chamamos sempre e ignoramos no web
  const recorder = ExpoAudioModule.useAudioRecorder(ExpoAudioModule.RecordingPresets.HIGH_QUALITY);
  return process.env.EXPO_OS !== 'web' ? recorder : null;
}

export default function PostDetailScreen() {
  const { colors } = useZivaTheme();
  const { id } = useLocalSearchParams<{ id: string }>();
  const postId = Array.isArray(id) ? id[0] : id;
  const { session } = useSession();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const userId = session?.user?.id ?? '';
  const inputRef = useRef<import('react-native').TextInput>(null);
  const mediaRecorderRef = useRef<any>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const audioRecorder = useCommentAudio();

  const [post, setPost] = useState<Post | null>(null);
  const [comments, setComments] = useState<Comment[]>([]);
  const [loading, setLoading] = useState(true);
  const [commentText, setCommentText] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [replyingTo, setReplyingTo] = useState<Comment | null>(null);
  const [editingComment, setEditingComment] = useState<Comment | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [pendingAudioUrl, setPendingAudioUrl] = useState<string | null>(null);

  const buildTree = (flat: Comment[]): Comment[] => {
    const map: Record<string, Comment> = {};
    flat.forEach((c) => { map[c.id] = { ...c, replies: [] }; });
    const roots: Comment[] = [];
    flat.forEach((c) => {
      if (c.parent_id && map[c.parent_id]) {
        map[c.parent_id].replies!.push(map[c.id]);
      } else {
        roots.push(map[c.id]);
      }
    });
    // Pinned first
    return roots.sort((a, b) => Number(b.is_pinned) - Number(a.is_pinned));
  };

  const load = useCallback(async () => {
    if (!postId) { setLoading(false); return; }
    setLoading(true);
    try {
      // Todas as queries em paralelo; post já inclui join com profiles via FK
      const [postRes, likeRes, commentsRes, commentLikesRes] = await Promise.all([
        supabase.from('posts')
          .select('id, user_id, caption, image_url, image_urls, likes_count, comments_count, created_at, video_url, post_type, profiles!user_id(id, username, full_name, avatar_url, is_verified)')
          .eq('id', postId)
          .maybeSingle(),
        supabase.from('likes').select('user_id').eq('post_id', postId).eq('user_id', userId).maybeSingle(),
        supabase.from('comments').select('*, profiles(username, full_name, avatar_url, is_verified)')
          .eq('post_id', postId).order('is_pinned', { ascending: false }).order('created_at', { ascending: true }),
        supabase.from('comment_likes').select('comment_id').eq('user_id', userId),
      ]);
      if (postRes.data) {
        const joined = Array.isArray(postRes.data.profiles) ? postRes.data.profiles[0] : postRes.data.profiles;
        const profileData = joined ?? { id: postRes.data.user_id, username: 'desconhecido', full_name: '', avatar_url: '' };
        setPost({
          ...postRes.data,
          profiles: profileData,
          liked: !!likeRes.data,
        });
      } else {
        setPost(null);
      }
      const likedCommentIds = new Set((commentLikesRes.data ?? []).map((l) => l.comment_id));
      const flatComments: Comment[] = (commentsRes.data ?? []).map((c) => {
        const cp = Array.isArray(c.profiles) ? c.profiles[0] : c.profiles;
        return {
          ...c,
          profiles: cp ?? { username: 'desconhecido', full_name: '', avatar_url: '' },
          liked: likedCommentIds.has(c.id),
        };
      });
      setComments(buildTree(flatComments));
    } catch { /* erro silencioso — UI mostra conteúdo vazio */ }
    setLoading(false);
  }, [postId, userId]);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  const handleLike = async () => {
    if (!post) return;
    const liked = post.liked;
    setPost((p) => p ? { ...p, liked: !liked, likes_count: liked ? p.likes_count - 1 : p.likes_count + 1 } : p);
    if (liked) await supabase.from('likes').delete().eq('post_id', postId).eq('user_id', userId);
    else await supabase.from('likes').insert({ post_id: postId, user_id: userId });
  };

  const handleComment = async () => {
    const text = commentText.trim();
    if (!text && !pendingAudioUrl) return;
    if (!postId) return;
    setSubmitting(true);
    try {
      if (editingComment) {
        await supabase.from('comments').update({ content: text }).eq('id', editingComment.id);
        setEditingComment(null);
      } else {
        const { data: newComment, error: insertErr } = await supabase.from('comments').insert({
          post_id: postId,
          user_id: userId,
          content: text || '🎤',
          audio_url: pendingAudioUrl ?? null,
          parent_id: replyingTo?.id ?? null,
        }).select('id').single();

        if (insertErr) throw insertErr;

        if (newComment) {
          const mentionedIds = await resolveMentions(text);
          if (mentionedIds.length > 0) {
            await supabase.from('mentions').insert(
              mentionedIds.map((mid) => ({ comment_id: newComment.id, mentioned_user_id: mid, mentioner_id: userId }))
            );
            await supabase.from('notifications').insert(
              mentionedIds.map((mid) => ({ user_id: mid, type: 'mention', actor_id: userId, post_id: postId }))
            );
          }
        }
        setReplyingTo(null);
      }
      setCommentText('');
      setPendingAudioUrl(null);
      load();
    } catch {
      // Erro silencioso — submitting será sempre resetado no finally
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (commentId: string) => {
    await supabase.from('comments').delete().eq('id', commentId);
    load();
  };

  const handlePin = async (commentId: string, pinned: boolean) => {
    // Unpin all first, then pin target
    await supabase.from('comments').update({ is_pinned: false }).eq('post_id', postId);
    if (!pinned) await supabase.from('comments').update({ is_pinned: true }).eq('id', commentId);
    load();
  };

  const handleLikeComment = async (commentId: string, alreadyLiked: boolean) => {
    if (alreadyLiked) {
      await supabase.from('comment_likes').delete().eq('comment_id', commentId).eq('user_id', userId);
      await supabase.rpc('decrement_comment_likes', { comment_id_arg: commentId });
    } else {
      await supabase.from('comment_likes').insert({ comment_id: commentId, user_id: userId });
      await supabase.rpc('increment_comment_likes', { comment_id_arg: commentId });
    }
    load();
  };

  const startEdit = (c: Comment) => {
    setEditingComment(c);
    setReplyingTo(null);
    setCommentText(c.content);
    inputRef.current?.focus();
  };

  const startReply = (c: Comment) => {
    setReplyingTo(c);
    setEditingComment(null);
    setCommentText('');
    inputRef.current?.focus();
  };

  const cancelAction = () => {
    setReplyingTo(null);
    setEditingComment(null);
    setCommentText('');
    setPendingAudioUrl(null);
  };

  // ── Gravação de áudio para comentário ────────────────────────────────────
  const uploadAudio = async (uri: string, ext: string): Promise<string> => {
    const path = `comments-audio/${userId}/${Date.now()}.${ext}`;
    const res = await fetch(uri);
    const buf = await res.arrayBuffer();
    await supabase.storage.from('ziva_images').upload(path, buf, { contentType: `audio/${ext}`, upsert: true });
    const { data } = supabase.storage.from('ziva_images').getPublicUrl(path);
    return data.publicUrl;
  };

  const toggleRecording = async () => {
    if (process.env.EXPO_OS === 'web') {
      if (!isRecording) {
        // Iniciar gravação web
        if (typeof navigator === 'undefined' || !navigator.mediaDevices) return;
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        audioChunksRef.current = [];
        // iOS Safari não suporta audio/webm — detectar mimeType suportado
        const mimeType = typeof MediaRecorder !== 'undefined' && MediaRecorder.isTypeSupported('audio/webm;codecs=opus')
          ? 'audio/webm;codecs=opus'
          : MediaRecorder.isTypeSupported('audio/mp4')
          ? 'audio/mp4'
          : '';
        const mrOptions = mimeType ? { mimeType } : {};
        const mr = new MediaRecorder(stream, mrOptions);
        mr.ondataavailable = (e) => { if (e.data.size > 0) audioChunksRef.current.push(e.data); };
        mr.start();
        mediaRecorderRef.current = mr;
        setIsRecording(true);
      } else {
        /* Parar e guardar */
        const mr = mediaRecorderRef.current;
        if (!mr) return;
        mr.onstop = async () => {
          setIsRecording(false);
          const audioType = mr.mimeType || 'audio/mp4';
          const ext = audioType.includes('webm') ? 'webm' : 'mp4';
          const blob = new Blob(audioChunksRef.current, { type: audioType });
          const path = `comments-audio/${userId}/${Date.now()}.${ext}`;
          const buf = await blob.arrayBuffer();
          await supabase.storage.from('ziva_images').upload(path, buf, { contentType: audioType, upsert: true });
          const { data } = supabase.storage.from('ziva_images').getPublicUrl(path);
          setPendingAudioUrl(data.publicUrl);
          mr.stream.getTracks().forEach((t: MediaStreamTrack) => t.stop());
        };
        mr.stop();
      }
    } else {
      // Native
      if (!isRecording) {
          const perm = await ExpoAudioModule.AudioModule.requestRecordingPermissionsAsync();
        if (!perm.granted) return;
        await audioRecorder?.record();
        setIsRecording(true);
      } else {
        await audioRecorder?.stop();
        setIsRecording(false);
        const uri = audioRecorder?.uri;
        if (uri) {
          const url = await uploadAudio(uri, 'm4a');
          setPendingAudioUrl(url);
        }
      }
    }
  };

  const flatComments = comments.reduce<Comment[]>((acc, c) => {
    acc.push(c);
    if (c.replies?.length) acc.push(...c.replies);
    return acc;
  }, []);

  if (loading) {
    return (
      <View className="flex-1 bg-background items-center justify-center">
        <ActivityIndicator size="large" color="#7c3aed" />
      </View>
    );
  }

  const goBack = () => router.canGoBack() ? router.back() : router.replace('/(app)/(tabs)/home' as any);

  if (!post) return (
    <View className="flex-1 bg-background items-center justify-center gap-3 px-8">
      <StatusBar style={colors.statusBar} backgroundColor={colors.bg} />
      <Text style={{ fontSize: 44 }}>😕</Text>
      <Text className="text-foreground text-lg font-bold text-center">Publicação não encontrada</Text>
      <Pressable onPress={goBack} className="bg-primary rounded-xl px-6 py-3 mt-2">
        <Text className="text-primary-foreground font-semibold">Voltar</Text>
      </Pressable>
    </View>
  );

  return (
    <KeyboardAvoidingView
      behavior={process.env.EXPO_OS === 'ios' ? 'padding' : 'height'}
      className="flex-1 bg-background"
      style={{ paddingTop: insets.top }}>
      <StatusBar style={colors.statusBar} backgroundColor={colors.bg} />

      {/* Header */}
      <View className="flex-row items-center px-4 py-3 gap-3 border-b border-border">
        <Pressable className="active:opacity-70" onPress={goBack}>
          <ArrowLeft size={22} color="#374151" />
        </Pressable>
        <Text className="font-bold text-foreground text-base flex-1">Publicação</Text>
        <View className="flex-row items-center gap-1.5">
          <MessageCircle size={16} color="#9ca3af" />
          <Text className="text-muted-foreground text-sm">{flatComments.length}</Text>
        </View>
      </View>

      <FlatList
        data={comments}
        keyExtractor={(item) => item.id}
        keyboardShouldPersistTaps="handled"
        contentInsetAdjustmentBehavior="automatic"
        ListHeaderComponent={
          <View>
            {/* Author */}
            <Pressable className="flex-row items-center px-4 py-3 gap-3 active:opacity-70"
              onPress={() => router.push(`/(app)/user/${post.profiles.id}` as any)}>
              <Image source={post.profiles.avatar_url ? { uri: post.profiles.avatar_url } : undefined}
                style={{ width: 42, height: 42, borderRadius: 21 }} contentFit="cover"
                placeholder={{ blurhash: 'LGF5]+Yk^6#M@-5c,1J5@[or[Q6.' }} />
              <View className="flex-1">
                <View className="flex-row items-center gap-1">
                  <Text className="font-bold text-foreground text-sm">{post.profiles.username}</Text>
                  {post.profiles.is_verified && <VerifiedBadge size={14} />}
                </View>
                <Text className="text-muted-foreground text-xs">{timeAgo(post.created_at)}</Text>
              </View>
            </Pressable>
            {/* Image */}
            {post.image_url ? (
              <Image source={{ uri: post.image_url }}
                style={{ width: '100%', aspectRatio: 1 }} contentFit="cover" />
            ) : null}
            {/* Actions */}
            <View className="px-4 py-3 gap-2">
              <Pressable onPress={handleLike}
                className="flex-row items-center gap-1.5 active:opacity-70 self-start">
                <Heart size={24} color={post.liked ? '#db2777' : '#6b7280'}
                  fill={post.liked ? '#db2777' : 'transparent'} strokeWidth={1.8} />
                <Text className="text-sm text-muted-foreground font-medium">{post.likes_count}</Text>
              </Pressable>
              {post.caption ? (
                <Text className="text-foreground text-sm">
                  <Text className="font-bold">{post.profiles.username} </Text>{post.caption}
                </Text>
              ) : null}
              <View className="h-px bg-border mt-2" />
              <Text className="font-bold text-muted-foreground text-xs uppercase tracking-wider">
                Comentários ({flatComments.length})
              </Text>
            </View>
          </View>
        }
        renderItem={({ item }) => (
          <CommentItem
            comment={item}
            postOwnerId={post.user_id}
            currentUserId={userId}
            onReply={startReply}
            onDelete={handleDelete}
            onEdit={startEdit}
            onPin={handlePin}
            onLike={handleLikeComment}
          />
        )}
        ListEmptyComponent={
          <View className="items-center py-10 gap-2">
            <Text style={{ fontSize: 36 }}>💬</Text>
            <Text className="text-muted-foreground text-sm">Sê o primeiro a comentar!</Text>
          </View>
        }
      />

      {/* Reply/Edit context banner */}
      {(replyingTo || editingComment) && (
        <View className="flex-row items-center px-4 py-2 bg-primary/10 border-t border-primary/20 gap-2">
          {editingComment
            ? <Pencil size={14} color="#7c3aed" />
            : <Reply size={14} color="#7c3aed" />}
          <Text className="flex-1 text-primary text-xs font-medium" numberOfLines={1}>
            {editingComment
              ? `A editar: ${editingComment.content}`
              : `A responder a @${replyingTo?.profiles.username}`}
          </Text>
          <Pressable onPress={cancelAction} className="active:opacity-60">
            <X size={16} color="#7c3aed" />
          </Pressable>
        </View>
      )}

      {/* Comment input */}
      <View className="border-t border-border bg-card"
        style={{ paddingBottom: Math.max(insets.bottom, 12) }}>
        {/* Prévia de áudio pendente */}
        {pendingAudioUrl && (
          <View className="flex-row items-center gap-2 px-4 pt-2">
            <View className="flex-1 flex-row items-center gap-2 bg-primary/10 rounded-xl px-3 py-2">
              <Play size={14} color="#7c3aed" />
              <Text className="text-primary text-xs flex-1" numberOfLines={1}>Áudio gravado</Text>
            </View>
            <Pressable onPress={() => setPendingAudioUrl(null)} className="active:opacity-60">
              <X size={16} color="#9ca3af" />
            </Pressable>
          </View>
        )}
        <View className="flex-row items-center px-4 py-3 gap-3">
          <MentionInput
            value={commentText}
            onChangeText={setCommentText}
            placeholder={replyingTo ? `Responder a @${replyingTo.profiles.username}...` : 'Adicionar comentário...'}
            multiline={false}
            style={{
              flex: 1,
              backgroundColor: colors.input,
              borderRadius: 999,
              paddingHorizontal: 16,
              paddingVertical: 10,
              color: colors.text,
              fontSize: 14,
            }}
          />
          {/* Botão de gravação de áudio */}
          <Pressable
            className={`w-10 h-10 rounded-full items-center justify-center active:opacity-70 ${isRecording ? 'bg-red-500' : 'bg-muted'}`}
            onPress={toggleRecording}>
            {isRecording
              ? <MicOff size={16} color="#fff" />
              : <Mic size={16} color="#9ca3af" />}
          </Pressable>
          {/* Botão enviar */}
          <Pressable
            className={`w-10 h-10 rounded-full items-center justify-center active:opacity-70 ${(commentText.trim() || pendingAudioUrl) ? 'bg-primary' : 'bg-muted'}`}
            onPress={handleComment}
            disabled={(!commentText.trim() && !pendingAudioUrl) || submitting}>
            {submitting
              ? <ActivityIndicator size="small" color="#7c3aed" />
              : editingComment
                ? <Check size={16} color={(commentText.trim() || pendingAudioUrl) ? '#fff' : '#9ca3af'} />
                : <Send size={16} color={(commentText.trim() || pendingAudioUrl) ? '#fff' : '#9ca3af'} />}
          </Pressable>
        </View>
      </View>
    </KeyboardAvoidingView>
  );
}
