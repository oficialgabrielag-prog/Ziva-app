import { useState, useCallback, useEffect } from 'react';
import {
  View, Text, FlatList, Pressable, ActivityIndicator, ScrollView,
  Modal, TextInput, KeyboardAvoidingView,
} from 'react-native';
import { useFocusEffect, useRouter, useLocalSearchParams } from 'expo-router';
import { Image } from 'expo-image';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ArrowLeft, Users, Lock, Globe, UserPlus, UserCheck, PenSquare } from 'lucide-react-native';
import type { RelativePathString } from 'expo-router';
import { supabase } from '@/client/supabase';
import { useSession } from '@/ctx';
import { VerifiedBadge } from '@/components/VerifiedBadge';
import { useZivaTheme } from '@/lib/theme-context';

interface CommunityDetail {
  id: string;
  name: string;
  description: string | null;
  cover_url: string | null;
  avatar_url: string | null;
  is_private: boolean;
  members_count: number;
  owner_id: string;
}

interface Post {
  id: string;
  caption: string;
  image_url: string;
  likes_count: number;
  comments_count: number;
  created_at: string;
  profiles: { username: string; avatar_url: string; is_verified: boolean };
}

export default function CommunityDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { session } = useSession();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const userId = session?.user?.id ?? '';
  const { colors } = useZivaTheme();

  const [community, setCommunity] = useState<CommunityDetail | null>(null);
  const [posts, setPosts] = useState<Post[]>([]);
  const [isMember, setIsMember] = useState(false);
  const [loading, setLoading] = useState(true);
  const [joining, setJoining] = useState(false);
  const [showPublish, setShowPublish] = useState(false);
  const [newCaption, setNewCaption] = useState('');
  const [publishing, setPublishing] = useState(false);
  const [publishError, setPublishError] = useState('');

  useFocusEffect(
    useCallback(() => {
      if (!id) return;
      (async () => {
        setLoading(true);
        const [comRes, memRes, postsRes] = await Promise.all([
          supabase.from('communities').select('*').eq('id', id).single(),
          supabase.from('community_members').select('id').eq('community_id', id).eq('user_id', userId).maybeSingle(),
          supabase.from('community_posts')
            .select('post_id')
            .eq('community_id', id)
            .order('created_at', { ascending: false })
            .limit(30),
        ]);
        setCommunity(comRes.data as CommunityDetail);
        setIsMember(!!memRes.data);

        if (postsRes.data && postsRes.data.length > 0) {
          const postIds = postsRes.data.map((p) => p.post_id);
          const { data: pData } = await supabase
            .from('posts')
            .select('id, caption, image_url, likes_count, comments_count, created_at, profiles(username, avatar_url, is_verified)')
            .in('id', postIds)
            .order('created_at', { ascending: false });
          setPosts((pData ?? []).map((p) => ({ ...p, profiles: Array.isArray(p.profiles) ? p.profiles[0] : p.profiles })) as Post[]);
        } else {
          // Fallback: buscar directamente pelo community_id no post
          const { data: directPosts } = await supabase
            .from('posts')
            .select('id, caption, image_url, likes_count, comments_count, created_at, profiles(username, avatar_url, is_verified)')
            .eq('community_id', id)
            .order('created_at', { ascending: false })
            .limit(30);
          if (directPosts && directPosts.length > 0) {
            setPosts(directPosts.map((p) => ({ ...p, profiles: Array.isArray(p.profiles) ? p.profiles[0] : p.profiles })) as Post[]);
          }
        }
        setLoading(false);
      })();
    }, [id, userId])
  );

  const toggleMembership = async () => {    if (!community || joining) return;
    setJoining(true);
    if (isMember) {
      await supabase.from('community_members').delete().eq('community_id', community.id).eq('user_id', userId);
      await supabase.rpc('decrement_community_members', { cid: community.id });
      setIsMember(false);
      setCommunity((prev) => prev ? { ...prev, members_count: Math.max(0, prev.members_count - 1) } : prev);
    } else {
      await supabase.from('community_members').insert({ community_id: community.id, user_id: userId });
      await supabase.rpc('increment_community_members', { cid: community.id });
      setIsMember(true);
      setCommunity((prev) => prev ? { ...prev, members_count: prev.members_count + 1 } : prev);
    }
    setJoining(false);
  };

  const handlePublishInCommunity = async () => {
    if (!newCaption.trim()) { setPublishError('Escreve algo para publicar.'); return; }
    setPublishing(true); setPublishError('');
    // Insere o post com community_id E post_type correto
    const { data: post, error: postErr } = await supabase
      .from('posts')
      .insert({
        user_id: userId,
        caption: newCaption.trim(),
        image_url: '',
        likes_count: 0,
        comments_count: 0,
        post_type: 'community_post',
        community_id: community!.id,
        status: 'published',
        is_deleted: false,
      })
      .select('id')
      .single();
    if (postErr || !post) { setPublishError('Erro ao publicar. Tenta novamente.'); setPublishing(false); return; }
    // Regista também na tabela de junção community_posts (dual-write)
    await supabase.from('community_posts').insert({ community_id: community!.id, post_id: post.id });
    // Carrega o post completo com dados do perfil
    const { data: pData } = await supabase
      .from('posts')
      .select('id, caption, image_url, likes_count, comments_count, created_at, profiles(username, avatar_url, is_verified)')
      .eq('id', post.id);
    if (pData) {
      setPosts((prev) => [
        ...(pData.map((p) => ({ ...p, profiles: Array.isArray(p.profiles) ? p.profiles[0] : p.profiles })) as Post[]),
        ...prev,
      ]);
    }
    setPublishing(false);
    setShowPublish(false);
    setNewCaption('');
  };

  // Realtime — novas publicações na comunidade aparecem automaticamente
  useEffect(() => {
    if (!id) return;
    const channel = supabase
      .channel(`community-posts-${id}`)
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'posts', filter: `community_id=eq.${id}` },
        async (payload) => {
          const newPost = payload.new as any;
          const { data: pData } = await supabase
            .from('posts')
            .select('id, caption, image_url, likes_count, comments_count, created_at, profiles(username, avatar_url, is_verified)')
            .eq('id', newPost.id)
            .single();
          if (pData) {
            const p = pData as any;
            setPosts((prev) => {
              if (prev.some((x) => x.id === p.id)) return prev;
              return [{ ...p, profiles: Array.isArray(p.profiles) ? p.profiles[0] : p.profiles } as Post, ...prev];
            });
          }
        }
      )
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [id]);

  if (loading || !community) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.bg, alignItems: 'center', justifyContent: 'center' }}>
        <StatusBar style={colors.statusBar} />
        <ActivityIndicator color="#7c3aed" size="large" />
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: colors.bg }}>
      <StatusBar style={colors.statusBar} />
      <FlatList
        data={posts}
        keyExtractor={(p) => p.id}
        contentInsetAdjustmentBehavior="automatic"
        ListHeaderComponent={
          <View>
            {/* Capa */}
            <View className="h-48 bg-primary/10 relative">
              {community.cover_url
                ? <Image source={{ uri: community.cover_url }} style={{ width: '100%', height: '100%' }} contentFit="cover" />
                : <View className="flex-1 items-center justify-center"><Users size={48} color="#7c3aed" strokeWidth={1.5} /></View>}
              {/* Botão voltar */}
              <Pressable
                onPress={() => router.canGoBack() ? router.back() : router.replace('/(app)/(tabs)/home' as any)}
                className="absolute top-0 left-4 bg-black/50 rounded-full p-2"
                style={{ marginTop: insets.top + 8 }}
              >
                <ArrowLeft size={20} color="#fff" />
              </Pressable>
            </View>

            {/* Info */}
            <View className="px-4 py-4 border-b border-border">
              <View className="flex-row items-start justify-between gap-3">
                <View className="flex-1">
                  <Text className="text-2xl font-bold text-foreground">{community.name}</Text>
                  <View className="flex-row items-center gap-2 mt-1">
                    {community.is_private
                      ? <><Lock size={12} color="#9ca3af" /><Text className="text-muted-foreground text-xs">Privada</Text></>
                      : <><Globe size={12} color="#9ca3af" /><Text className="text-muted-foreground text-xs">Pública</Text></>}
                    <Text className="text-muted-foreground text-xs">· {community.members_count} membros</Text>
                  </View>
                  {community.description
                    ? <Text className="text-muted-foreground text-sm mt-2">{community.description}</Text>
                    : null}
                </View>
                <Pressable
                  onPress={toggleMembership}
                  disabled={joining}
                  className={`flex-row items-center gap-2 px-4 py-2.5 rounded-2xl ${isMember ? 'bg-secondary border border-border' : 'bg-primary'}`}
                >
                  {joining
                    ? <ActivityIndicator size="small" color={isMember ? '#374151' : '#fff'} />
                    : isMember
                      ? <><UserCheck size={16} color="#374151" /><Text className="font-bold text-sm text-foreground">Membro</Text></>
                      : <><UserPlus size={16} color="#fff" /><Text className="font-bold text-sm text-primary-foreground">Entrar</Text></>}
                </Pressable>
              </View>
            </View>

            {posts.length > 0 && <Text className="px-4 pt-4 pb-2 font-bold text-foreground">Publicações</Text>}
          </View>
        }
        renderItem={({ item }) => (
          <Pressable
            className="mx-4 mb-3 p-4 bg-card rounded-2xl border border-border active:opacity-80"
            style={{ borderCurve: 'continuous' }}
            onPress={() => router.push(`/(app)/post/${item.id}` as RelativePathString)}
          >
            <View className="flex-row items-center gap-2 mb-2">
              <Image source={item.profiles?.avatar_url ? { uri: item.profiles.avatar_url } : undefined}
                style={{ width: 32, height: 32, borderRadius: 16 }} contentFit="cover" />
              <Text className="font-semibold text-foreground text-sm">@{item.profiles?.username}</Text>
              {item.profiles?.is_verified && <VerifiedBadge size={14} />}
            </View>
            {item.caption ? <Text className="text-foreground text-sm mb-2" numberOfLines={3}>{item.caption}</Text> : null}
            {item.image_url ? <Image source={{ uri: item.image_url }} style={{ width: '100%', height: 180, borderRadius: 12 }} contentFit="cover" /> : null}
            <Text className="text-muted-foreground text-xs mt-2">❤️ {item.likes_count} · 💬 {item.comments_count}</Text>
          </Pressable>
        )}
        ListEmptyComponent={
          <View className="items-center py-16 gap-3 px-8">
            <Text style={{ fontSize: 44 }}>📝</Text>
            <Text className="text-foreground text-lg font-bold text-center">Ainda não há publicações</Text>
            {isMember && (
              <Pressable onPress={() => setShowPublish(true)} className="bg-primary rounded-full px-6 py-3 mt-2">
                <Text className="text-primary-foreground font-bold">Publicar na comunidade</Text>
              </Pressable>
            )}
          </View>
        }
      />

      {/* FAB — publicar na comunidade */}
      {isMember && (
        <Pressable
          onPress={() => setShowPublish(true)}
          style={{
            position: 'absolute', bottom: insets.bottom + 20, right: 20,
            backgroundColor: '#7c3aed', width: 56, height: 56, borderRadius: 28,
            alignItems: 'center', justifyContent: 'center',
            shadowColor: '#7c3aed', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.4, shadowRadius: 12,
          }}
        >
          <PenSquare size={24} color="#fff" />
        </Pressable>
      )}

      {/* Modal — nova publicação na comunidade */}
      <Modal visible={showPublish} transparent animationType="slide" onRequestClose={() => setShowPublish(false)}>
        <KeyboardAvoidingView
          behavior={process.env.EXPO_OS === 'ios' ? 'padding' : 'height'}
          style={{ flex: 1, backgroundColor: colors.overlay, justifyContent: 'flex-end' }}>
          <View style={{ backgroundColor: colors.card, borderTopLeftRadius: 24, borderTopRightRadius: 24,
            padding: 24, gap: 16, borderTopWidth: 1, borderTopColor: colors.cardBorder }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
              <Text style={{ fontSize: 18, fontWeight: '800', color: colors.text }}>Nova publicação</Text>
              <Pressable onPress={() => { setShowPublish(false); setNewCaption(''); setPublishError(''); }}>
                <Text style={{ color: colors.muted, fontSize: 15 }}>✕</Text>
              </Pressable>
            </View>
            <TextInput
              value={newCaption}
              onChangeText={setNewCaption}
              placeholder="Partilha algo com a comunidade..."
              placeholderTextColor={colors.placeholder}
              multiline
              style={{
                borderWidth: 1, borderColor: publishError ? '#ef4444' : colors.inputBorder,
                borderRadius: 12, padding: 14, fontSize: 15, color: colors.text,
                minHeight: 100, textAlignVertical: 'top', backgroundColor: colors.input,
              }}
            />
            {publishError ? <Text style={{ color: '#ef4444', fontSize: 13 }}>{publishError}</Text> : null}
            <Pressable
              onPress={handlePublishInCommunity}
              disabled={publishing}
              style={{ backgroundColor: '#7c3aed', borderRadius: 14, padding: 16, alignItems: 'center', opacity: publishing ? 0.6 : 1 }}>
              {publishing
                ? <ActivityIndicator color="#fff" />
                : <Text style={{ color: '#fff', fontWeight: '700', fontSize: 15 }}>Publicar</Text>}
            </Pressable>
          </View>
        </KeyboardAvoidingView>
      </Modal>
    </View>
  );
}
