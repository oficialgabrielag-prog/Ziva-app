import { useState, useCallback } from 'react';
import {
  View, Text, FlatList, Pressable, TextInput,
  ActivityIndicator, Modal, KeyboardAvoidingView, ScrollView,
} from 'react-native';
import { useFocusEffect, useRouter } from 'expo-router';
import { Image } from 'expo-image';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Plus, Users, X, Lock, Globe, Search } from 'lucide-react-native';
import * as ImagePicker from 'expo-image-picker';
import { fetch } from 'expo/fetch';
import type { RelativePathString } from 'expo-router';

import { supabase } from '@/client/supabase';
import { useSession } from '@/ctx';

// ─── Types ───────────────────────────────────────────────────────────────────
interface Community {
  id: string;
  name: string;
  description: string | null;
  cover_url: string | null;
  avatar_url: string | null;
  is_private: boolean;
  members_count: number;
  posts_count: number;
  owner_id: string;
  is_member?: boolean;
}

// ─── Ecrã de Comunidades ─────────────────────────────────────────────────────
export default function CommunitiesScreen() {
  const { session } = useSession();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const userId = session?.user?.id ?? '';

  const [tab, setTab] = useState<'discover' | 'mine'>('discover');
  const [communities, setCommunities] = useState<Community[]>([]);
  const [mine, setMine] = useState<Community[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showCreate, setShowCreate] = useState(false);

  // Criar comunidade
  const [createName, setCreateName] = useState('');
  const [createDesc, setCreateDesc] = useState('');
  const [createPrivate, setCreatePrivate] = useState(false);
  const [createCover, setCreateCover] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);

  useFocusEffect(
    useCallback(() => {
      (async () => {
        setLoading(true);

        // Comunidades que o utilizador pertence
        const { data: memberData } = await supabase
          .from('community_members')
          .select('community_id')
          .eq('user_id', userId);
        const memberIds = new Set((memberData ?? []).map((m) => m.community_id));

        // Todas as comunidades
        const { data: allData } = await supabase
          .from('communities')
          .select('*')
          .order('members_count', { ascending: false })
          .limit(40);
        const enriched = (allData ?? []).map((c) => ({ ...c, is_member: memberIds.has(c.id) }));
        setCommunities(enriched as Community[]);
        setMine(enriched.filter((c) => c.is_member) as Community[]);
        setLoading(false);
      })();
    }, [userId])
  );

  const joinCommunity = async (cid: string, already: boolean) => {
    setCommunities((prev) => prev.map((c) => c.id === cid ? { ...c, is_member: !already, members_count: c.members_count + (already ? -1 : 1) } : c));
    setMine((prev) => {
      if (already) return prev.filter((c) => c.id !== cid);
      const found = communities.find((c) => c.id === cid);
      return found ? [...prev, { ...found, is_member: true }] : prev;
    });
    if (already) {
      await supabase.from('community_members').delete().eq('community_id', cid).eq('user_id', userId);
      await supabase.rpc('decrement_community_members', { cid });
    } else {
      await supabase.from('community_members').insert({ community_id: cid, user_id: userId });
      await supabase.rpc('increment_community_members', { cid });
    }
  };

  const pickCover = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') return;
    const r = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], quality: 0.8 });
    if (!r.canceled) setCreateCover(r.assets[0].uri);
  };

  const createCommunity = async () => {
    if (!createName.trim() || creating) return;
    setCreating(true);
    let coverUrl: string | null = null;
    if (createCover) {
      const res = await fetch(createCover);
      const ab = await res.arrayBuffer();
      const path = `community_covers/${userId}/${Date.now()}.jpg`;
      await supabase.storage.from('ziva_images').upload(path, ab, { contentType: 'image/jpeg', upsert: true });
      const { data: u } = supabase.storage.from('ziva_images').getPublicUrl(path);
      coverUrl = u.publicUrl;
    }
    const { data } = await supabase.from('communities').insert({
      name: createName.trim(),
      description: createDesc.trim() || null,
      is_private: createPrivate,
      owner_id: userId,
      cover_url: coverUrl,
    }).select('id').single();
    if (data?.id) {
      await supabase.from('community_members').insert({ community_id: data.id, user_id: userId, role: 'admin' });
      setShowCreate(false);
      setCreateName(''); setCreateDesc(''); setCreatePrivate(false); setCreateCover(null);
      router.push(`/(app)/communities/${data.id}` as RelativePathString);
    }
    setCreating(false);
  };

  const filtered = (tab === 'mine' ? mine : communities).filter((c) =>
    !search.trim() || c.name.toLowerCase().includes(search.toLowerCase())
  );

  const renderCommunity = ({ item }: { item: Community }) => (
    <Pressable
      className="mx-4 mb-4 rounded-2xl bg-card border border-border overflow-hidden active:opacity-80"
      style={{ borderCurve: 'continuous' }}
      onPress={() => router.push(`/(app)/communities/${item.id}` as RelativePathString)}
    >
      {/* Capa */}
      <View className="h-28 bg-primary/10 relative">
        {item.cover_url
          ? <Image source={{ uri: item.cover_url }} style={{ width: '100%', height: '100%' }} contentFit="cover" />
          : <View className="flex-1 items-center justify-center"><Users size={36} color="#7c3aed" strokeWidth={1.5} /></View>}
        {item.is_private && (
          <View className="absolute top-2 right-2 bg-black/60 rounded-full px-2 py-1 flex-row items-center gap-1">
            <Lock size={10} color="#fff" />
            <Text className="text-white text-xs">Privada</Text>
          </View>
        )}
      </View>
      <View className="p-3 flex-row items-center gap-3">
        <View className="flex-1">
          <Text className="text-foreground font-bold text-base" numberOfLines={1}>{item.name}</Text>
          {item.description ? <Text className="text-muted-foreground text-xs mt-0.5" numberOfLines={1}>{item.description}</Text> : null}
          <Text className="text-muted-foreground text-xs mt-1">{item.members_count} membros</Text>
        </View>
        <Pressable
          onPress={() => joinCommunity(item.id, !!item.is_member)}
          className={`rounded-full px-4 py-2 ${item.is_member ? 'bg-secondary border border-border' : 'bg-primary'}`}
        >
          <Text className={`text-xs font-bold ${item.is_member ? 'text-foreground' : 'text-primary-foreground'}`}>
            {item.is_member ? 'Membro' : 'Entrar'}
          </Text>
        </Pressable>
      </View>
    </Pressable>
  );

  return (
    <View className="flex-1 bg-background">
      <StatusBar style="dark" />
      {/* Header */}
      <View className="px-4 pb-3 border-b border-border" style={{ paddingTop: insets.top + 8 }}>
        <View className="flex-row items-center justify-between mb-3">
          <Text className="text-2xl font-bold text-foreground">Comunidades</Text>
          <Pressable onPress={() => setShowCreate(true)} className="bg-primary rounded-full px-4 py-2 flex-row items-center gap-1.5">
            <Plus size={15} color="#fff" />
            <Text className="text-white font-bold text-sm">Criar</Text>
          </Pressable>
        </View>
        {/* Barra de pesquisa */}
        <View className="flex-row items-center bg-muted rounded-xl px-3 py-2.5 gap-2">
          <Search size={16} color="#9ca3af" />
          <TextInput
            value={search}
            onChangeText={setSearch}
            placeholder="Pesquisar comunidades..."
            placeholderTextColor="#9ca3af"
            className="flex-1 text-foreground text-sm"
          />
        </View>
        {/* Tabs */}
        <View className="flex-row mt-3 gap-2">
          {(['discover', 'mine'] as const).map((t) => (
            <Pressable key={t} onPress={() => setTab(t)}
              className={`flex-1 py-2 rounded-xl items-center ${tab === t ? 'bg-primary' : 'bg-muted'}`}>
              <Text className={`text-sm font-semibold ${tab === t ? 'text-white' : 'text-muted-foreground'}`}>
                {t === 'discover' ? '🌍 Descobrir' : '👥 As minhas'}
              </Text>
            </Pressable>
          ))}
        </View>
      </View>

      {loading ? (
        <View className="flex-1 items-center justify-center"><ActivityIndicator color="#7c3aed" size="large" /></View>
      ) : (
        <FlatList
          data={filtered}
          keyExtractor={(c) => c.id}
          renderItem={renderCommunity}
          contentInsetAdjustmentBehavior="automatic"
          contentContainerStyle={{ paddingVertical: 16 }}
          ListEmptyComponent={
            <View className="items-center py-20 gap-3 px-8">
              <Text style={{ fontSize: 48 }}>👥</Text>
              <Text className="text-foreground text-xl font-bold text-center">
                {tab === 'mine' ? 'Ainda não fazes parte de nenhuma comunidade' : 'Nenhuma comunidade encontrada'}
              </Text>
              <Pressable onPress={() => setShowCreate(true)} className="bg-primary rounded-full px-6 py-3 mt-2">
                <Text className="text-primary-foreground font-bold">Criar a primeira</Text>
              </Pressable>
            </View>
          }
        />
      )}

      {/* Modal criar comunidade */}
      <Modal visible={showCreate} transparent animationType="slide">
        <View className="flex-1 justify-end bg-black/50">
          <KeyboardAvoidingView behavior={process.env.EXPO_OS === 'ios' ? 'padding' : 'height'}>
            <ScrollView className="bg-background rounded-t-3xl" contentContainerStyle={{ padding: 24, gap: 16, paddingBottom: insets.bottom + 24 }}>
              <View className="flex-row items-center justify-between">
                <Text className="text-xl font-bold text-foreground">Criar Comunidade</Text>
                <Pressable onPress={() => setShowCreate(false)}><X size={22} color="#9ca3af" /></Pressable>
              </View>

              {/* Capa */}
              <Pressable onPress={pickCover} className="h-32 bg-muted rounded-2xl items-center justify-center border-2 border-dashed border-border active:opacity-70">
                {createCover
                  ? <Image source={{ uri: createCover }} style={{ width: '100%', height: '100%', borderRadius: 16 }} contentFit="cover" />
                  : <><Users size={28} color="#9ca3af" /><Text className="text-muted-foreground text-xs mt-2">Adicionar capa</Text></>}
              </Pressable>

              <TextInput
                value={createName}
                onChangeText={setCreateName}
                placeholder="Nome da comunidade"
                placeholderTextColor="#9ca3af"
                className="bg-muted rounded-xl px-4 py-3 text-foreground border border-border"
                maxLength={60}
              />
              <TextInput
                value={createDesc}
                onChangeText={setCreateDesc}
                placeholder="Descrição (opcional)"
                placeholderTextColor="#9ca3af"
                className="bg-muted rounded-xl px-4 py-3 text-foreground border border-border"
                multiline
                numberOfLines={3}
                maxLength={200}
              />

              {/* Privacidade */}
              <View className="flex-row gap-3">
                {[{ val: false, label: '🌍 Pública', Icon: Globe }, { val: true, label: '🔒 Privada', Icon: Lock }].map((opt) => (
                  <Pressable key={String(opt.val)}
                    onPress={() => setCreatePrivate(opt.val)}
                    className={`flex-1 flex-row items-center justify-center gap-2 py-3 rounded-xl border ${createPrivate === opt.val ? 'bg-primary border-primary' : 'bg-muted border-border'}`}>
                    <Text className={`font-semibold text-sm ${createPrivate === opt.val ? 'text-white' : 'text-muted-foreground'}`}>{opt.label}</Text>
                  </Pressable>
                ))}
              </View>

              <Pressable
                onPress={createCommunity}
                disabled={creating || !createName.trim()}
                className="bg-primary rounded-2xl py-4 items-center"
                style={{ opacity: creating || !createName.trim() ? 0.6 : 1 }}
              >
                {creating
                  ? <ActivityIndicator color="#fff" />
                  : <Text className="text-primary-foreground font-bold text-base">Criar Comunidade</Text>}
              </Pressable>
            </ScrollView>
          </KeyboardAvoidingView>
        </View>
      </Modal>
    </View>
  );
}
