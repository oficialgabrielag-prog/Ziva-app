import { Stack } from 'expo-router';
import { UnreadProvider } from '@/lib/unread-context';

export default function AppLayout() {
  return (
    <UnreadProvider>
      <Stack screenOptions={{ headerShown: false }}>
        <Stack.Screen name="(tabs)" />
        <Stack.Screen name="aura-chat" />
        <Stack.Screen name="post" />
        <Stack.Screen name="user" />
        <Stack.Screen name="messages" />
        <Stack.Screen name="settings" />
        <Stack.Screen name="live" />
        <Stack.Screen name="communities" />
        <Stack.Screen name="creator-studio" />
        <Stack.Screen name="photo-to-video" />
        <Stack.Screen name="ai-config" />
      </Stack>
    </UnreadProvider>
  );
}
