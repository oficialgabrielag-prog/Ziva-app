import { useState, useCallback } from 'react';
import {
  View, Text, FlatList, Pressable, ActivityIndicator, TextInput,
} from 'react-native';
import { useFocusEffect, useRouter } from 'expo-router';
import { Image } from 'expo-image';
import { MessageCircle, Search, PenSquare, X } from 'lucide-react-native';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { supabase } from '@/client/supabase';
import { useSession } from '@/ctx';
import { useZivaTheme } from '@/lib/theme-context';

// ─── Types ────────────────────────────────────────────────────────────────────
interface Conversation {
  id: string;
  participant_one: string;
  participant_two: string;
  last_message: string;
  last_message_at: string;
  unread_count: number;
  other: { id: string; username: string; full_name: string; avatar_url: string; is_verified: boolean };
}

interface SearchProfile {
  id: string;
  username: string;
  full_name: string;
  avatar_url: string;
  is_verified: boolean;
}

function timeAgo(dateStr: string): string {
  if (!dateStr) return '';
  const s = Math.floor((Date.now() - new Date(dateStr).getTime()) / 1000);
  if (s < 60) return 'agora';
  if (s < 3600) return `${Math.floor(s / 60)}min`;
  if (s < 86400) return `${Math.floor(s / 3600)}h`;
  if (s < 604800) return `${Math.floor(s / 86400)}d`;
  return new Date(dateStr).toLocaleDateString('pt-AO', { day: '2-digit', month: 'short' });
}

// ─── Ecrã ─────────────────────────────────────────────────────────────────────
export default function MessagesListScreen() {
  const { session } = useSession();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const userId = session?.user?.id ?? '';
  const { colors } = useZivaTheme();

  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [searching, setSearching] = useState(false);
  const [searchResults, setSearchResults] = useState<SearchProfile[]>([]);
  const [startingConv, setStartingConv] = useState<string | null>(null);

  // ── Carregar conversas ──────────────────────────────────────────────────────
  useFocusEffect(
    useCallback(() => {
      if (!userId) return;
      (async () => {
        setLoading(true);
        const { data: convData } = await supabase
          .from('conversations')
          .select('id, participant_one, participant_two, last_message, last_message_at, unread_one, unread_two')
          .or(`participant_one.eq.${userId},participant_two.eq.${userId}`)
          .order('last_message_at', { ascending: false });

        if (!convData) { setLoading(false); return; }

        const otherIds = convData.map((c) =>
          c.participant_one === userId ? c.participant_two : c.participant_one
        );
        const { data: profiles } = await supabase
          .from('profiles')
          .select('id, username, full_name, avatar_url, is_verified')
          .in('id', otherIds.length > 0 ? otherIds : ['00000000-0000-0000-0000-000000000000']);

        const profMap: Record<string, SearchProfile> = {};
        for (const p of profiles ?? []) profMap[p.id] = p as SearchProfile;

        setConversations(
          convData.map((c) => {
            const otherId = c.participant_one === userId ? c.participant_two : c.participant_one;
            const unread = c.participant_one === userId ? (c.unread_one ?? 0) : (c.unread_two ?? 0);
            return {
              ...c,
              unread_count: unread,
              other: profMap[otherId] ?? { id: otherId, username: 'Utilizador', full_name: '', avatar_url: '', is_verified: false },
            };
          })
        );
        setLoading(false);
      })();
    }, [userId])
  );

  // ── Pesquisar utilizadores ──────────────────────────────────────────────────
  const handleSearch = async (q: string) => {
    setSearchQuery(q);
    if (!q.trim()) { setSearchResults([]); setSearching(false); return; }
    setSearching(true);
    const { data } = await supabase
      .from('profiles')
      .select('id, username, full_name, avatar_url, is_verified')
      .ilike('username', `%${q}%`)
      .neq('id', userId)
      .limit(20);
    setSearchResults((data ?? []) as SearchProfile[]);
    setSearching(false);
  };

  // ── Iniciar conversa ────────────────────────────────────────────────────────
  const handleStartConversation = async (profile: SearchProfile) => {
    setStartingConv(profile.id);
    try {
      const { data, error } = await supabase.rpc('get_or_create_conversation', {
        other_user_id: profile.id,
      });
      if (error) throw error;
      setSearchQuery('');
      setSearchResults([]);
      router.push(`/(app)/messages/${data}` as any);
    } catch { /* silencia */ }
    setStartingConv(null);
  };

  const totalUnread = conversations.reduce((sum, c) => sum + (c.unread_count ?? 0), 0);

  return (
    <View style={{ flex: 1, backgroundColor: colors.bg }}>
      <StatusBar style={colors.statusBar} />

      {/* Header */}
      <View style={{
        paddingTop: insets.top + 8, paddingBottom: 14,
        paddingHorizontal: 16,
        borderBottomWidth: 0.5, borderBottomColor: colors.cardBorder,
      }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 14 }}>
          <View style={{ flex: 1 }}>
            <Text style={{ fontSize: 22, fontWeight: '800', color: colors.text }}>
              Mensagens
              {totalUnread > 0 && (
                <Text style={{ fontSize: 14, color: colors.purple, fontWeight: '700' }}>
                  {' '}· {totalUnread}
                </Text>
              )}
            </Text>
          </View>
          <Pressable
            onPress={() => setSearchQuery(searchQuery ? '' : ' ')}
            style={{
              width: 38, height: 38, borderRadius: 12,
              backgroundColor: colors.input,
              alignItems: 'center', justifyContent: 'center',
            }}
            className="active:opacity-70">
            {searchQuery ? <X size={18} color={colors.muted} /> : <PenSquare size={18} color={colors.muted} />}
          </Pressable>
        </View>

        {/* Barra de pesquisa */}
        <View style={{
          flexDirection: 'row', alignItems: 'center', gap: 10,
          backgroundColor: colors.input, borderRadius: 14, borderWidth: 1,
          borderColor: colors.inputBorder, paddingHorizontal: 14, paddingVertical: 10,
        }}>
          <Search size={16} color={colors.muted} />
          <TextInput
            value={searchQuery}
            onChangeText={handleSearch}
            placeholder="Pesquisar ou iniciar conversa…"
            placeholderTextColor={colors.placeholder}
            style={{ flex: 1, fontSize: 14, color: colors.text }}
          />
          {searching && <ActivityIndicator size="small" color={colors.purple} />}
        </View>
      </View>

      {/* Resultados de pesquisa */}
      {searchQuery.trim() ? (
        <FlatList
          data={searchResults}
          keyExtractor={(item) => item.id}
          contentInsetAdjustmentBehavior="automatic"
          renderItem={({ item }) => (
            <Pressable
              onPress={() => handleStartConversation(item)}
              disabled={startingConv === item.id}
              style={{ flexDirection: 'row', alignItems: 'center', padding: 16, gap: 12 }}
              className="active:opacity-70">
              <Image
                source={item.avatar_url ? { uri: item.avatar_url } : undefined}
                style={{ width: 48, height: 48, borderRadius: 24, backgroundColor: colors.input }}
                contentFit="cover" />
              <View style={{ flex: 1 }}>
                <Text style={{ fontWeight: '700', color: colors.text, fontSize: 14 }}>{item.username}</Text>
                {item.full_name ? (
                  <Text style={{ color: colors.muted, fontSize: 12, marginTop: 1 }}>{item.full_name}</Text>
                ) : null}
              </View>
              {startingConv === item.id
                ? <ActivityIndicator size="small" color={colors.purple} />
                : <View style={{
                    backgroundColor: colors.purple, borderRadius: 20,
                    paddingHorizontal: 14, paddingVertical: 6,
                  }}>
                    <Text style={{ fontSize: 12, color: '#fff', fontWeight: '700' }}>Mensagem</Text>
                  </View>
              }
            </Pressable>
          )}
          ListEmptyComponent={
            <View style={{ alignItems: 'center', paddingVertical: 40, gap: 8 }}>
              <Text style={{ color: colors.muted, fontSize: 14 }}>
                {searching ? 'A pesquisar…' : 'Nenhum utilizador encontrado'}
              </Text>
            </View>
          }
        />
      ) : loading ? (
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
          <ActivityIndicator size="large" color={colors.purple} />
        </View>
      ) : (
        <FlatList
          data={conversations}
          keyExtractor={(item) => item.id}
          contentInsetAdjustmentBehavior="automatic"
          renderItem={({ item }) => {
            const hasUnread = item.unread_count > 0;
            return (
              <Pressable
                onPress={() => router.push(`/(app)/messages/${item.id}` as any)}
                style={{ flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 12, gap: 12 }}
                className="active:bg-muted/50">
                {/* Avatar */}
                <View style={{ position: 'relative' }}>
                  <Image
                    source={item.other.avatar_url ? { uri: item.other.avatar_url } : undefined}
                    style={{ width: 54, height: 54, borderRadius: 27, backgroundColor: colors.input }}
                    contentFit="cover"
                    placeholder={{ blurhash: 'LGF5]+Yk^6#M@-5c,1J5@[or[Q6.' }} />
                  <View style={{
                    position: 'absolute', bottom: 1, right: 1, width: 13, height: 13,
                    borderRadius: 7, backgroundColor: '#22C55E', borderWidth: 2.5, borderColor: colors.bg,
                  }} />
                </View>
                {/* Info */}
                <View style={{ flex: 1, gap: 3 }}>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5 }}>
                    <Text style={{
                      fontWeight: hasUnread ? '800' : '600',
                      color: colors.text, fontSize: 15, flex: 1,
                    }} numberOfLines={1}>{item.other.username}</Text>
                    <Text style={{ fontSize: 11, color: hasUnread ? '#A78BFA' : colors.muted, fontWeight: hasUnread ? '700' : '400' }}>
                      {timeAgo(item.last_message_at)}
                    </Text>
                  </View>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                    <Text style={{
                      flex: 1, fontSize: 13,
                      color: hasUnread ? colors.text : colors.muted,
                      fontWeight: hasUnread ? '600' : '400',
                    }} numberOfLines={1}>
                      {item.last_message || 'Iniciar conversa…'}
                    </Text>
                    {hasUnread && (
                      <View style={{
                        backgroundColor: colors.purple, borderRadius: 12,
                        minWidth: 20, height: 20, paddingHorizontal: 5,
                        alignItems: 'center', justifyContent: 'center',
                      }}>
                        <Text style={{ fontSize: 11, color: '#fff', fontWeight: '800' }}>
                          {item.unread_count > 99 ? '99+' : item.unread_count}
                        </Text>
                      </View>
                    )}
                  </View>
                </View>
              </Pressable>
            );
          }}
          ItemSeparatorComponent={() => (
            <View style={{ height: 0.5, backgroundColor: colors.cardBorder, marginLeft: 82 }} />
          )}
          ListEmptyComponent={
            <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', paddingVertical: 80, gap: 14 }}>
              <View style={{
                width: 72, height: 72, borderRadius: 36,
                backgroundColor: 'rgba(123,63,242,0.1)', alignItems: 'center', justifyContent: 'center',
                borderWidth: 2, borderColor: 'rgba(123,63,242,0.3)',
              }}>
                <MessageCircle size={32} color={colors.purple} strokeWidth={1.5} />
              </View>
              <Text style={{ fontSize: 18, fontWeight: '700', color: colors.text }}>Sem mensagens</Text>
              <Text style={{ color: colors.muted, textAlign: 'center', paddingHorizontal: 32, fontSize: 14 }}>
                Pesquisa por alguém acima para iniciar uma conversa
              </Text>
            </View>
          }
        />
      )}
    </View>
  );
}
