import { useState, useCallback, useRef, useEffect } from 'react';
import {
  View, Text, FlatList, Pressable, ActivityIndicator,
  TextInput, KeyboardAvoidingView, Modal,
} from 'react-native';
import { Image } from 'expo-image';
import { useFocusEffect, useRouter, useLocalSearchParams } from 'expo-router';
import * as ImagePicker from 'expo-image-picker';
import { fetch as expoFetch } from 'expo/fetch';
import { ArrowLeft, Send, Check, CheckCheck, Image as ImageIcon, Smile, Trash, Reply, MoreVertical } from 'lucide-react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';

import { supabase } from '@/client/supabase';
import { useSession } from '@/ctx';
import { useZivaTheme } from '@/lib/theme-context';

// ─── Types ────────────────────────────────────────────────────────────────────
interface Reaction { emoji: string; user_id: string; }
interface ReplyRef  { id: string; content: string; sender_id: string; message_type: string; }

interface Message {
  id: string;
  content: string;
  sender_id: string;
  created_at: string;
  is_read: boolean;
  delivered_at: string | null;
  read_at: string | null;
  deleted_at: string | null;
  message_type: 'text' | 'image' | 'voice' | 'system';
  media_url?: string | null;
  reply_to_id?: string | null;
  reply_to?: ReplyRef | null;
  reactions?: Reaction[];
}

interface OtherUser {
  id: string;
  username: string;
  avatar_url: string;
  full_name: string;
}

const QUICK_EMOJIS = ['❤️', '😂', '😮', '😢', '👏', '🔥'];

function timeStr(dateStr: string): string {
  return new Date(dateStr).toLocaleTimeString('pt-AO', { hour: '2-digit', minute: '2-digit' });
}

function MessageStatus({ msg, isMe }: { msg: Message; isMe: boolean }) {
  if (!isMe) return null;
  if (msg.read_at)      return <CheckCheck size={13} color="#a78bfa" />;
  if (msg.delivered_at) return <CheckCheck size={13} color="rgba(255,255,255,0.55)" />;
  return <Check size={13} color="rgba(255,255,255,0.4)" />;
}

// ─── Ecrã principal ───────────────────────────────────────────────────────────
export default function ChatScreen() {
  const { id: convId } = useLocalSearchParams<{ id: string }>();
  const { session } = useSession();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const userId = session?.user?.id ?? '';
  const { colors } = useZivaTheme();
  const flatListRef = useRef<FlatList>(null);

  const [messages, setMessages]       = useState<Message[]>([]);
  const [other, setOther]             = useState<OtherUser | null>(null);
  const [loading, setLoading]         = useState(true);
  const [text, setText]               = useState('');
  const [sending, setSending]         = useState(false);
  const [otherTyping, setOtherTyping] = useState(false);
  const [otherOnline, setOtherOnline] = useState(false);
  const [uploadingMedia, setUploadingMedia] = useState(false);
  const [replyTo, setReplyTo]         = useState<Message | null>(null);
  const [longPressMsg, setLongPressMsg] = useState<Message | null>(null);

  const typingBroadcastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const otherTypingTimer     = useRef<ReturnType<typeof setTimeout> | null>(null);
  const channelRef           = useRef<ReturnType<typeof supabase.channel> | null>(null);

  // ── Carregar mensagens ──────────────────────────────────────────────────────
  useFocusEffect(useCallback(() => {
    if (!convId) return;
    (async () => {
      setLoading(true);
      const { data: conv } = await supabase
        .from('conversations').select('participant_one, participant_two').eq('id', convId).single();
      if (conv) {
        const otherId = conv.participant_one === userId ? conv.participant_two : conv.participant_one;
        const { data: prof } = await supabase
          .from('profiles').select('id, username, avatar_url, full_name').eq('id', otherId).single();
        setOther(prof);
      }
      const { data: msgs } = await supabase
        .from('messages')
        .select('id, content, sender_id, created_at, is_read, delivered_at, read_at, deleted_at, message_type, media_url, reply_to_id, reply_to:reply_to_id(id, content, sender_id, message_type), reactions:message_reactions(emoji, user_id)')
        .eq('conversation_id', convId)
        .order('created_at', { ascending: true });
      setMessages((msgs ?? []) as unknown as Message[]);
      // Marcar como lidas via RPC
      supabase.rpc('mark_conversation_read', { conv_id: convId });
      setLoading(false);
    })();
  }, [convId, userId]));

  // ── Realtime: mensagens + typing broadcast + presence ──────────────────────
  useEffect(() => {
    if (!convId || !userId) return;

    const ch = supabase.channel(`chat:${convId}`, { config: { presence: { key: userId } } });
    channelRef.current = ch;

    // Novas mensagens / updates
    ch.on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages', filter: `conversation_id=eq.${convId}` },
      (payload) => {
        const msg = payload.new as Message;
        setMessages((prev) => prev.find((m) => m.id === msg.id) ? prev : [...prev, msg]);
        setTimeout(() => flatListRef.current?.scrollToEnd({ animated: true }), 100);
        if (msg.sender_id !== userId)
          supabase.rpc('mark_conversation_read', { conv_id: convId });
      }
    ).on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'messages', filter: `conversation_id=eq.${convId}` },
      (payload) => {
        const updated = payload.new as Message;
        setMessages((prev) => prev.map((m) => m.id === updated.id ? { ...m, ...updated } : m));
      }
    )
    // Typing broadcast
    .on('broadcast', { event: 'typing' }, (payload) => {
      if (payload.payload?.user_id === userId) return;
      setOtherTyping(true);
      if (otherTypingTimer.current) clearTimeout(otherTypingTimer.current);
      otherTypingTimer.current = setTimeout(() => setOtherTyping(false), 3000);
    })
    // Presence: online/offline
    .on('presence', { event: 'sync' }, () => {
      const state = ch.presenceState();
      const others = Object.keys(state).filter((k) => k !== userId);
      setOtherOnline(others.length > 0);
    })
    .subscribe(async (status) => {
      if (status === 'SUBSCRIBED') {
        await ch.track({ user_id: userId, online_at: new Date().toISOString() });
      }
    });

    return () => { supabase.removeChannel(ch); };
  }, [convId, userId]);

  // ── Broadcast typing ───────────────────────────────────────────────────────
  const broadcastTyping = () => {
    channelRef.current?.send({ type: 'broadcast', event: 'typing', payload: { user_id: userId } });
    if (typingBroadcastTimer.current) clearTimeout(typingBroadcastTimer.current);
    typingBroadcastTimer.current = setTimeout(() => {}, 3000);
  };

  // ── Enviar mensagem ────────────────────────────────────────────────────────
  const handleSend = async (overrideContent?: string, type: Message['message_type'] = 'text', mediaUrl?: string) => {
    const content = overrideContent ?? text.trim();
    if ((!content && !mediaUrl) || !convId) return;
    setSending(true);
    setText('');
    const replyId = replyTo?.id ?? null;
    const savedReplyTo = replyTo;
    setReplyTo(null);

    const { data } = await supabase.from('messages')
      .insert({
        conversation_id: convId,
        sender_id: userId,
        content: content || '',
        message_type: type,
        reply_to_id: replyId,
        media_url: mediaUrl ?? null,
        delivered_at: new Date().toISOString(),
      })
      .select('id, content, sender_id, created_at, is_read, delivered_at, read_at, deleted_at, message_type, media_url, reply_to_id')
      .single();

    if (data) {
      const newMsg = { ...data, reactions: [], reply_to: savedReplyTo ? { id: savedReplyTo.id, content: savedReplyTo.content, sender_id: savedReplyTo.sender_id, message_type: savedReplyTo.message_type } : null } as Message;
      setMessages((prev) => [...prev, newMsg]);
      supabase.from('conversations').update({ last_message: type === 'text' ? content : '📎 ' + type, last_message_at: new Date().toISOString() }).eq('id', convId);
      setTimeout(() => flatListRef.current?.scrollToEnd({ animated: true }), 100);
    }
    setSending(false);
  };

  // ── Anexar imagem ──────────────────────────────────────────────────────────
  const handleAttachImage = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') return;
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], allowsEditing: true, quality: 0.8 });
    if (result.canceled) return;
    setUploadingMedia(true);
    try {
      const uri = result.assets[0].uri;
      const resp = await expoFetch(uri);
      const buf = await resp.arrayBuffer();
      const path = `chat/${convId}/${userId}/${Date.now()}.jpg`;
      const { error: upErr } = await supabase.storage.from('ziva_images').upload(path, buf, { contentType: 'image/jpeg' });
      if (upErr) throw upErr;
      const { data: urlData } = supabase.storage.from('ziva_images').getPublicUrl(path);
      await handleSend('', 'image', urlData.publicUrl);
    } catch { /* silencia */ }
    setUploadingMedia(false);
  };

  // ── Reação ─────────────────────────────────────────────────────────────────
  const handleReact = async (msg: Message, emoji: string) => {
    setLongPressMsg(null);
    await supabase.rpc('toggle_message_reaction', { msg_id: msg.id, reaction_emoji: emoji });
    // Update local state optimistically
    setMessages((prev) => prev.map((m) => {
      if (m.id !== msg.id) return m;
      const reactions = m.reactions ?? [];
      const existing = reactions.find((r) => r.emoji === emoji && r.user_id === userId);
      return {
        ...m,
        reactions: existing
          ? reactions.filter((r) => !(r.emoji === emoji && r.user_id === userId))
          : [...reactions, { emoji, user_id: userId }],
      };
    }));
  };

  // ── Apagar mensagem ────────────────────────────────────────────────────────
  const handleDelete = async (msgId: string) => {
    setLongPressMsg(null);
    await supabase.rpc('delete_message', { msg_id: msgId });
    setMessages((prev) => prev.map((m) => m.id === msgId ? { ...m, deleted_at: new Date().toISOString(), content: '' } : m));
  };

  // ── Render bolha ───────────────────────────────────────────────────────────
  const renderMessage = ({ item }: { item: Message }) => {
    const isMe = item.sender_id === userId;
    const deleted = !!item.deleted_at;

    const reactionMap: Record<string, number> = {};
    for (const r of item.reactions ?? []) reactionMap[r.emoji] = (reactionMap[r.emoji] ?? 0) + 1;
    const reactionEntries = Object.entries(reactionMap);

    const bubbleBg = deleted ? colors.input : isMe ? colors.purple : colors.card;

    return (
      <View style={{ flexDirection: 'row', justifyContent: isMe ? 'flex-end' : 'flex-start', marginBottom: 2 }}>
        <Pressable
          onPress={() => {}}
          onLongPress={() => !deleted && setLongPressMsg(item)}
          style={{ maxWidth: '78%' }}>
          {/* Reply preview */}
          {item.reply_to && !deleted && (
            <View style={{
              backgroundColor: isMe ? 'rgba(255,255,255,0.1)' : colors.input,
              borderLeftWidth: 3, borderLeftColor: colors.purple,
              borderRadius: 8, padding: 8, marginBottom: 4, marginHorizontal: 2,
            }}>
              <Text style={{ fontSize: 11, color: colors.purple, fontWeight: '700', marginBottom: 2 }}>
                {item.reply_to.sender_id === userId ? 'Tu' : other?.username ?? ''}
              </Text>
              <Text style={{ fontSize: 12, color: colors.muted }} numberOfLines={2}>
                {item.reply_to.message_type === 'image' ? '📷 Imagem' : item.reply_to.content}
              </Text>
            </View>
          )}

          {/* Bubble */}
          <View style={{
            backgroundColor: bubbleBg,
            borderRadius: 18,
            borderTopRightRadius: isMe ? 4 : 18,
            borderTopLeftRadius: isMe ? 18 : 4,
            paddingHorizontal: deleted ? 14 : item.message_type === 'image' ? 4 : 14,
            paddingVertical: deleted ? 9 : item.message_type === 'image' ? 4 : 9,
            overflow: 'hidden',
          }}>
            {deleted ? (
              <Text style={{ fontSize: 14, color: colors.muted, fontStyle: 'italic' }}>Mensagem apagada</Text>
            ) : item.message_type === 'image' && item.media_url ? (
              <Image source={{ uri: item.media_url }} style={{ width: 220, height: 200, borderRadius: 14 }} contentFit="cover" />
            ) : (
              <Text style={{ fontSize: 15, color: isMe ? '#fff' : colors.text, lineHeight: 22 }}>
                {item.content}
              </Text>
            )}

            {!deleted && (
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: item.message_type === 'image' ? 6 : 3, justifyContent: 'flex-end', paddingHorizontal: item.message_type === 'image' ? 6 : 0, paddingBottom: item.message_type === 'image' ? 4 : 0 }}>
                <Text style={{ fontSize: 11, color: isMe ? 'rgba(255,255,255,0.6)' : colors.muted }}>
                  {timeStr(item.created_at)}
                </Text>
                <MessageStatus msg={item} isMe={isMe} />
              </View>
            )}
          </View>

          {/* Reações */}
          {reactionEntries.length > 0 && (
            <View style={{
              flexDirection: 'row', gap: 4, marginTop: 4,
              justifyContent: isMe ? 'flex-end' : 'flex-start',
            }}>
              {reactionEntries.map(([emoji, count]) => (
                <Pressable key={emoji} onPress={() => handleReact(item, emoji)}
                  style={{
                    backgroundColor: colors.card, borderRadius: 20,
                    paddingHorizontal: 7, paddingVertical: 3,
                    flexDirection: 'row', alignItems: 'center', gap: 3,
                    borderWidth: 1, borderColor: 'rgba(123,63,242,0.3)',
                  }}>
                  <Text style={{ fontSize: 12 }}>{emoji}</Text>
                  {count > 1 && <Text style={{ fontSize: 11, color: colors.muted }}>{count}</Text>}
                </Pressable>
              ))}
            </View>
          )}
        </Pressable>
      </View>
    );
  };

  return (
    <KeyboardAvoidingView
      behavior={process.env.EXPO_OS === 'ios' ? 'padding' : 'height'}
      style={{ flex: 1, backgroundColor: colors.bg, paddingTop: insets.top }}>
      <StatusBar style={colors.statusBar} />

      {/* Header */}
      <View style={{
        flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16,
        paddingVertical: 12, gap: 12, borderBottomWidth: 0.5, borderBottomColor: colors.cardBorder,
        backgroundColor: colors.card,
      }}>
        <Pressable onPress={() => router.canGoBack() ? router.back() : router.replace('/(app)/(tabs)/home' as any)} className="active:opacity-70">
          <ArrowLeft size={22} color={colors.text} />
        </Pressable>
        {other && (
          <Pressable style={{ flexDirection: 'row', alignItems: 'center', gap: 10, flex: 1 }}
            onPress={() => router.push(`/(app)/user/${other.id}` as any)} className="active:opacity-70">
            <View style={{ position: 'relative' }}>
              <Image source={other.avatar_url ? { uri: other.avatar_url } : undefined}
                style={{ width: 40, height: 40, borderRadius: 20, backgroundColor: colors.input }} contentFit="cover" />
              <View style={{
                position: 'absolute', bottom: 0, right: 0, width: 12, height: 12, borderRadius: 6,
                backgroundColor: otherOnline ? '#22C55E' : colors.muted,
                borderWidth: 2, borderColor: colors.card,
              }} />
            </View>
            <View>
              <Text style={{ fontWeight: '700', color: colors.text, fontSize: 15 }}>{other.username}</Text>
              <Text style={{ fontSize: 11, color: otherTyping ? colors.purple : otherOnline ? '#22C55E' : colors.muted }}>
                {otherTyping ? 'a escrever…' : otherOnline ? 'Online' : 'Offline'}
              </Text>
            </View>
          </Pressable>
        )}
        <Pressable onPress={() => {}} className="active:opacity-70">
          <MoreVertical size={20} color={colors.muted} />
        </Pressable>
      </View>

      {/* Messages */}
      {loading ? (
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
          <ActivityIndicator size="large" color={colors.purple} />
        </View>
      ) : (
        <FlatList
          ref={flatListRef}
          data={messages}
          keyExtractor={(item) => item.id}
          renderItem={renderMessage}
          contentContainerStyle={{ padding: 14, gap: 4, paddingBottom: 8 }}
          contentInsetAdjustmentBehavior="automatic"
          keyboardShouldPersistTaps="handled"
          onContentSizeChange={() => flatListRef.current?.scrollToEnd({ animated: false })}
          ListEmptyComponent={
            <View style={{ alignItems: 'center', paddingVertical: 60 }}>
              <Text style={{ color: colors.muted, fontSize: 14 }}>Diz olá! 👋</Text>
            </View>
          }
        />
      )}

      {/* Reply preview bar */}
      {replyTo && (
        <View style={{
          flexDirection: 'row', alignItems: 'center', gap: 10,
          backgroundColor: colors.card, paddingHorizontal: 16, paddingVertical: 8,
          borderTopWidth: 0.5, borderTopColor: colors.cardBorder,
        }}>
          <Reply size={16} color={colors.purple} />
          <View style={{ flex: 1, borderLeftWidth: 2, borderLeftColor: colors.purple, paddingLeft: 8 }}>
            <Text style={{ fontSize: 11, color: colors.purple, fontWeight: '700' }}>A responder</Text>
            <Text style={{ fontSize: 12, color: colors.muted }} numberOfLines={1}>{replyTo.content || '📷 Imagem'}</Text>
          </View>
          <Pressable onPress={() => setReplyTo(null)} className="active:opacity-70">
            <View style={{ width: 22, height: 22, borderRadius: 11, backgroundColor: colors.input, alignItems: 'center', justifyContent: 'center' }}>
              <Text style={{ fontSize: 14, color: colors.muted }}>×</Text>
            </View>
          </Pressable>
        </View>
      )}

      {/* Input bar */}
      <View style={{
        flexDirection: 'row', alignItems: 'center', paddingHorizontal: 14,
        paddingVertical: 10, gap: 10, borderTopWidth: 0.5,
        borderTopColor: colors.cardBorder, backgroundColor: colors.card,
        paddingBottom: Math.max(insets.bottom, 12),
      }}>
        <Pressable onPress={handleAttachImage} disabled={uploadingMedia} className="active:opacity-70"
          style={{ width: 38, height: 38, borderRadius: 12, backgroundColor: colors.input, alignItems: 'center', justifyContent: 'center' }}>
          {uploadingMedia
            ? <ActivityIndicator size="small" color={colors.purple} />
            : <ImageIcon size={18} color={colors.muted} />}
        </Pressable>

        <TextInput
          value={text}
          onChangeText={(v) => { setText(v); broadcastTyping(); }}
          placeholder="Escreve uma mensagem…"
          placeholderTextColor={colors.placeholder}
          style={{
            flex: 1, backgroundColor: colors.input, borderRadius: 22,
            paddingHorizontal: 16, paddingVertical: 10, fontSize: 14,
            color: colors.text, maxHeight: 100,
            borderWidth: 1, borderColor: colors.inputBorder,
          }}
          returnKeyType="send"
          onSubmitEditing={() => handleSend()}
          multiline
        />

        <Pressable onPress={() => {}} className="active:opacity-70"
          style={{ width: 38, height: 38, borderRadius: 12, backgroundColor: colors.input, alignItems: 'center', justifyContent: 'center' }}>
          <Smile size={18} color={colors.muted} />
        </Pressable>

        <Pressable
          onPress={() => handleSend()}
          disabled={(!text.trim() && !uploadingMedia) || sending}
          style={{
            width: 42, height: 42, borderRadius: 21, alignItems: 'center', justifyContent: 'center',
            backgroundColor: text.trim() ? colors.purple : colors.input,
            shadowColor: colors.purple, shadowOffset: { width: 0, height: 3 }, shadowOpacity: text.trim() ? 0.4 : 0, shadowRadius: 8,
          }}>
          {sending
            ? <ActivityIndicator size="small" color="#fff" />
            : <Send size={17} color={text.trim() ? '#fff' : colors.muted} />}
        </Pressable>
      </View>

      {/* Long press modal */}
      <Modal transparent visible={!!longPressMsg} animationType="fade" onRequestClose={() => setLongPressMsg(null)}>
        <Pressable style={{ flex: 1, backgroundColor: colors.overlay, justifyContent: 'center', alignItems: 'center', padding: 24 }}
          onPress={() => setLongPressMsg(null)}>
          <View style={{ backgroundColor: colors.card, borderRadius: 20, padding: 20, width: '100%', maxWidth: 340, gap: 14,
            borderWidth: 1, borderColor: colors.cardBorder }}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-around' }}>
              {QUICK_EMOJIS.map((e) => (
                <Pressable key={e} onPress={() => longPressMsg && handleReact(longPressMsg, e)}
                  style={{ width: 44, height: 44, borderRadius: 22, backgroundColor: colors.input, alignItems: 'center', justifyContent: 'center' }}
                  className="active:opacity-70">
                  <Text style={{ fontSize: 22 }}>{e}</Text>
                </Pressable>
              ))}
            </View>

            <Pressable onPress={() => { if (longPressMsg) setReplyTo(longPressMsg); setLongPressMsg(null); }}
              style={{ flexDirection: 'row', alignItems: 'center', gap: 12, padding: 12, borderRadius: 12, backgroundColor: colors.input }}
              className="active:opacity-70">
              <Reply size={18} color={colors.muted} />
              <Text style={{ color: colors.text, fontWeight: '600' }}>Responder</Text>
            </Pressable>

            {longPressMsg?.sender_id === userId && (
              <Pressable onPress={() => longPressMsg && handleDelete(longPressMsg.id)}
                style={{ flexDirection: 'row', alignItems: 'center', gap: 12, padding: 12, borderRadius: 12, backgroundColor: 'rgba(239,68,68,0.1)', borderWidth: 1, borderColor: 'rgba(239,68,68,0.25)' }}
                className="active:opacity-70">
                <Trash size={18} color={colors.danger} />
                <Text style={{ color: colors.danger, fontWeight: '600' }}>Apagar mensagem</Text>
              </Pressable>
            )}
          </View>
        </Pressable>
      </Modal>
    </KeyboardAvoidingView>
  );
}

